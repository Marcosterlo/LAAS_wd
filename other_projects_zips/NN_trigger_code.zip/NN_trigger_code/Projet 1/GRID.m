function[c,PTS] = GRID(Ps,lim,passo)
P = cell(2,1);
P{1} = Ps(1:2,1:2)-Ps(1:2,3:4)*inv(Ps(3:4,3:4))*Ps(3:4,1:2);
P{2} = Ps(3:4,3:4)-Ps(3:4,1:2)*inv(Ps(1:2,1:2))*Ps(1:2,3:4);
pts_lim_xy = [];
pts_lim_zk = [];
pts = [];
Sxy = double.empty;
Szk = double.empty;
a = 1;
for x = linspace(-lim(1),lim(1),passo)
    b = 1;
    for y = linspace(-lim(2),lim(2),passo)
        c = 1;
        for z = linspace(-lim(3),lim(3),passo)
            d = 1;
            for k = linspace(-lim(4),lim(4),passo)
                vetor = [x; y; z; k];
                V = [x; y; z; k]'*Ps*[x; y; z; k];
                V_proj_xy = [x; y]'*P{1}*[x; y];
                V_proj_zk = [z; k]'*P{2}*[z; k];
                if V<= 1
                    pts = [pts, [x; y; z; k]];
                    if V_proj_xy<= 1
                        pts_lim_xy = [pts_lim_xy, [x;y;z;k]];
                        Sxy(a,b) = 1;
                    else
                        Sxy(a,b) = 0;
                    end
                    if V_proj_zk<= 1
                        pts_lim_zk = [pts_lim_zk, [x;y;z;k]];
                        Szk(c,d) = 1;
                    else
                        Szk(c,d) = 0;
                    end
                end
                d = d+1;
            end
            c = c+1;
        end
        b = b+1;
    end
    a = a+1;
end
Pts_lim_xy = [];
Pts_lim_zk = [];
b = 1; d = 1;
for i = 1:size(Sxy,1)
    k = min(find(Sxy(i,:)));
    j = max(find(Sxy(i,:)));
    if k~= 0
        Pts_lim_xy = [Pts_lim_xy, pts_lim_xy(:,b), pts_lim_xy(:,b+j-k)];
        b = b+j-k+1;
    end
end
for i = 1:size(Szk,1)
    l = min(find(Szk(i,:)));
    m = max(find(Szk(i,:)));
    if l~=0
        Pts_lim_zk = [Pts_lim_xy,pts_lim_zk(:,d), pts_lim_zk(:,d+m-l)];
        d = d+m-l+1;
    end
end
PTS = [Pts_lim_xy, Pts_lim_zk];
end