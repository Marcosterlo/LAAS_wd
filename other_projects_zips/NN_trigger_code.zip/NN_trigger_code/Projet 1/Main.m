clear all
clc
%% Inverted pendulum
% parameters
g = 10; % gravitational coefficient
m = 0.15; % mass
l = 0.5; % length
mu = 0.05; % frictional coefficient
dt = 0.02; % sampling period

% x^+ = AG*x + BG*u
sysP.AG = [1, dt;...
      g/l*dt, 1-mu/(m*l^2)*dt];
% describes how u enters the system
sysP.BG2 = [0;...
      dt/(m*l^2)];
sysP.BG1 = [0;...
      -g/l*dt];
sys.nG = size(sysP.AG, 1);
nu = 1;  
   
fname = 'Wb_s32_tanh/';
W{1} = load([fname 'W1.csv']);
W{2} = load([fname 'W2.csv']);
W{3} = load([fname 'W3.csv']);
sysC.W = W;

%load('file_W4_ini.mat')

%% Generic Transport Model
% 
% sysP.AG = [0.935 0.019;-0.907 0.913];
% sysP.BG2 = [-0.006;-1.120];
% 
% sys.nG = size(sysP.AG, 1);
% nu = 1; 

%% Vehicle lateral control
% 
% % parameters
% % Nominal speed of the vehicle travels at.
% U = 28; % m/s
% % Model
% % Front cornering stiffness for one wheel.
% Ca1 = -61595; % unit: Newtons/rad
% % Rear cornering stiffness for one wheel.
% Ca3 = -52095; % unit: Newtons/rad
% 
% % Front cornering stiffness for two wheels.
% Caf = Ca1*2; % unit: Newtons/rad
% % Rear cornering stiffness for two wheels.
% Car = Ca3*2; % unit: Newtons/rad
% 
% % Vehicle mass
% m = 1670; % kg
% % Moment of inertia
% Iz = 2100; % kg/m^2
% 
% % Distance from vehicle CG to front axle
% a = 0.99; % m
% % Distance from vehicle CG to rear axle
% b = 1.7; % m
% 
% g = 9.81;
% 
% % sampling period
% dt = 0.02;
% 
% % Continuous-time state space matrices
% % States are lateral displacement(e) and heading angle error(deltaPsi) and 
% % their derivatives.
% % Inputs are front wheel angle and curvature of the road.
% Ac = [0 1 0 0; ...
%       0, (Caf+Car)/(m*U), -(Caf+Car)/m, (a*Caf-b*Car)/(m*U); ...
%       0 0 0 1; ...
%       0, (a*Caf-b*Car)/(Iz*U), -(a*Caf-b*Car)/Iz, (a^2*Caf+b^2*Car)/(Iz*U)];
% B1c = [0; 
%       -Caf/m;
%       0; ...
%       -a*Caf/Iz];
% 
% % x^+ = AG*x + BG1*u
% 
% sysP.AG = Ac*dt + eye(4);
% 
% % describes how q enters the system
% sysP.BG2 = B1c*dt;
% % 
% % % load weights and biases of the NN controller     
% fname = 'Wb_s32_tanh_car/';
% W{1} = load([fname 'W1.csv']);
% W{2} = load([fname 'W2.csv']);
% W{3} = load([fname 'W3.csv']);
% sysC.W = W;

%%

nlayer = numel(W)-1;

b = cell(1,nlayer);
n = zeros(1,nlayer);
for i=1:nlayer+1
    n(i) = size(W{i},1);
    b{i} = zeros(n(i),1);
    sysC.W{i} = W{i};
    sysC.b{i} = b{i};
end
nphi = sum(n(1:nlayer));

xeq = [0.0; 0.0];
veq = cell(1,nlayer);
weq = cell(1,nlayer);
vup = cell(1,nlayer);
vlb = cell(1,nlayer);
wup = cell(1,nlayer);
wlb = cell(1,nlayer);
alpha = cell(1,nlayer);

beta = 1;
up = 0;
lb = 0;
Alpha = [];

veq{1} = W{1}*xeq + b{1};
weq{1} = tanh(veq{1});
for i = 2:nlayer
    veq{i} = W{i}*weq{i-1} + b{i};
    weq{i} = tanh(veq{i});
end

x1bound = 2.5;
x2bound = 6;
% x3bound = 1;
% x4bound = 5;
% w0up = [x1bound; x2bound];% x3bound; x4bound];
% w0lb = -w0up;
% vup{1} = [];
% vlb{1} = [];
% for i = 1:n(1)
%     up = W{1}(i,:)*1/2*(w0up+w0lb) + b{1}(i) + abs(W{1}(i,:))*1/2*abs(w0up-w0lb);
%     lb = W{1}(i,:)*1/2*(w0up+w0lb) + b{1}(i) - abs(W{1}(i,:))*1/2*abs(w0up-w0lb);
%     vup{1} = [vup{1}; up];
%     vlb{1} = [vlb{1}; lb];
% end

deltav1 = 0.5;
vup{1} = deltav1 + veq{1};
vlb{1} = veq{1} - deltav1;

alpha{1} = min((tanh(vup{1})-tanh(veq{1}))./(vup{1}-veq{1}), (tanh(veq{1})-tanh(vlb{1}))./(veq{1}-vlb{1}));
wup{1} = tanh(vup{1});
wlb{1} = tanh(vlb{1});
for i = 1:nlayer
    if i>1
        for j = 1:n(i)
            up = W{i}(j,:)*1/2*(wup{i-1}+wlb{i-1}) + b{i}(j) + abs(W{i}(j,:))*1/2*abs(wup{i-1}-wlb{i-1});
            lb = W{i}(j,:)*1/2*(wup{i-1}+wlb{i-1}) + b{i}(j) - abs(W{i}(j,:))*1/2*abs(wup{i-1}-wlb{i-1});
            vup{i} = [vup{i}; up];
            vlb{i} = [vlb{i}; lb];
        end
        alpha{i} = min((tanh(vup{i})-tanh(veq{i}))./(vup{i}-veq{i}), (tanh(veq{i})-tanh(vlb{i}))./(veq{i}-vlb{i}));
        wup{i} = tanh(vup{i});
        wlb{i} = tanh(vlb{i});
    end
    Alpha = blkdiag(Alpha,diag(alpha{i}));
end
Beta = beta*eye(nphi);

%% Convex Optimization - compute trigger parameters and ROA

%[sol,solPb] = code_NN_feasibility(sysP,sysC,Alpha,Beta)

%[sol,solPb] = code_NN_trigger(sysP,sysC,Alpha,Beta)

[sol,solPb] = code_NN_trigger_w(sysP,sysC,Alpha,Beta)

%[sol,solPb] = code_NN_trigger_wx(sysP,sysC,Alpha,Beta)

%% plot results
% Simulation results
Nstep = 500;
[vet val] = eig(sol.P);
x0 = 1/sqrt(val(1,1))*vet(:,1)
%x0 = 1/sqrt(val(2,2))*vet(:,2);

q_a = 0;
ptsp = [];
for i=1:120
    q = randi(5330,1,1);
    if q ~= q_a
       ptsp = [ptsp, pts(:,q)];
       q_a = q;
    end
end

Nstep = 500;
% sumup_traj = zeros(2,1);
% sumup_total = zeros(2,1);
% for i=1:74:7400
%subplot(1,2,1)
for i=-6:0.6:6
     for j=-6:0.6:6
           x0 = [i,j];
           [x,u,update,sumup,vet_error] = NN_trigger_w_closedloop(Nstep,sysP,x0,W,b,sol.Qe,sol.Qw);
%            sumup_traj = [sumup_traj sumup];
         if abs(x(1,end))>1
            plot(x(1,2:end),x(2,2:end),'g-.','LineWidth',1)
            hold on
            plot(x(1,2),x(2,2),'g*')%,'MarkerFaceColor','c')
         else
            plot(x(1,2:end),x(2,2:end),'k-','LineWidth',1) 
            hold on
            plot(x(1,2),x(2,2),'ks')
         end
      end
%end
end
xlim([-6 6])
ylim([-6 6])
% axis square
set(gca,'Ticklabelinterpreter','latex')
line([-2.5 -2.5],[-6 6])
% sumup_total(1) = mean(sumup_traj(1,2:end));
% sumup_total(2) = mean(sumup_traj(2,2:end));
% sumup_total
% sum(sumup_total)

[x,u,update,sumup,vet_error] = NN_trigger_wx_closedloopT(Nstep,x0,{W1,W2,W3},{b1,b2,b3},sol.Qex,sol.Qew,sol.Qx,sol.Qw,g,m,l,mu,dt);

k = 1:1:Nstep;
subplot(2,1,1)
stairs(k,x(1,2:end),'Color','g','LineStyle','-.','LineWidth',1.2);
hold on
stairs(k,x(2,2:end),'Color','b','LineStyle','-.','LineWidth',1.2);
% stairs(k,x(3,2:end),'LineStyle','-','LineWidth',1);
% stairs(k,x(4,2:end),'LineStyle','-','LineWidth',1);
set(gca,'Ticklabelinterpreter','latex')
xlabel('$k$' ,'interpreter','latex')
ylabel('$x_k$','interpreter','latex');
h=legend('$x_1$','$x_2$','Location', 'northeast');
set(h,'Interpreter','latex');
grid

ax2 = axes('position',[.757 .816 .163 .145],'Box','on');
axes(ax2)
%hold on
%stairs(k(50:100),x(1,50:100),'LineStyle','-','LineWidth',1.2,'Color','b');%,'Marker','o', 'MarkerEdgeColor','auto', 'MarkerFaceColor','auto')
hold on
stairs(k(5:30),x(2,5:30),'LineStyle','-.','LineWidth',1,'Color','b');
%ylim([-1.4 -0.7])
grid
% 
% control 
subplot(2,1,2)
hold on
stairs(k,u(1,1:end),'Color','r','LineStyle','-.','LineWidth',1.2);
xlabel('$k$' ,'interpreter','latex')
ylabel('$u_k$','interpreter','latex');
set(gca,'Ticklabelinterpreter','latex')
h=legend( '$u_k$','Location', 'northeast');
set(h,'Interpreter','latex');
grid

ax3 = axes('position',[.683 .272 .163 .145],'Box','on');
axes(ax3)
hold on
stairs(k(5:30),u(1,5:30),'LineStyle','-.','LineWidth',1.2,'Color','r');%,'Marker','o', 'MarkerEdgeColor','auto', 'MarkerFaceColor','auto')
%ylim([-1.4 -0.7])
grid
% inter-events
% 
% figure(2)
% aux = 1;
% for i = 2:Nstep
%     if update(i)~= 0
%         stem(i-2, i-aux-1,'bo','MarkerFaceColor','auto');
%         aux = i;
%         hold on
%     end
% end
figure(3)
aux = zeros(2,1);
for k = 2:Nstep
    for i = 1:2
        if update(i,k)== 1
            subplot(2,1,i)
            p2 = stem(k-2, k-aux(i)-1,'LineStyle','-.','Color','c','Marker','^','MarkerSize',3, 'MarkerFaceColor','auto');
            aux(i) = k;
            hold on
        end
        set(gca,'Ticklabelinterpreter','latex')
        xlabel('$k$','interpreter','latex');
    end
end
ylabel('Inter-events $(\omega^2)$' ,'interpreter','latex')
grid

% 
%ROA
figure(2)
x1 = linspace(-1.5,1.5,100);
x2 = linspace(-3.9,3.9,100);
pts = [];
for i = 1:100
    for j =1:100
        V = [x1(i),x2(j)]*sol.P*[x1(i);x2(j)];
        if V <=1
            pts = [pts, [x1(i);x2(j)]];
            plot(x1(i),x2(j),'.','color',mycolor('orange') );
            hold on
        end
    end
end

[U D V] = svd(sol.P);

z = 1/sqrt(D(1,1));
y = 1/sqrt(D(2,2));
theta = [0:1/20:2*pi+1/20];

state(1,:) = z*cos(theta); 
state(2,:) = y*sin(theta);

X = V * state;
hold on
plot(X(1,:),X(2,:),'Color','b','LineWidth',1.2,'LineStyle' ,'-');

figure(2)
x1 = linspace(-6,6,1e3);
for i=1:n(1)
    plot(x1,(deltav1-W{1}(i,1)*x1)/W{1}(i,2),'color','m')%mycolor('orange')) 
    plot(x1,(-deltav1-W{1}(i,1)*x1)/W{1}(i,2),'color','m')%,mycolor('orange'))
    hold on;
end
%-------------------------------------------------------
blue =   [0.000,  0.447,  0.741];
orange = [0.850,  0.325,  0.098];

figure(1)

x = [0.1 0.2 0.3 0.4 0.5];
yl1 = [99.78 99.68 99.47 99.28 98.85];
yl2 = [58.27 48.90 36.50 31.41 24.19];
yyaxis left
plot(x,yl1,'-','LineWidth',1.2,'MarkerEdgeColor',blue,'MarkerFaceColor',blue)
hold on
plot(x,yl2,'-.','LineWidth',1.2,'MarkerEdgeColor',blue,'MarkerFaceColor',blue)
%xlabel('$n$','Interpreter','latex')
ylabel('$\omega^1$','Interpreter','latex')
xlabel('$\alpha|_{\bar{v}^1}$','Interpreter','latex')

yr1 = [99.93 99.33 98.93 98.51 97.69 ];
yr2 = [27.53 21.91 21.84 21.70 21.61];
yyaxis right
plot(x,yr1,'-','LineWidth',1.2,'MarkerEdgeColor',orange,'MarkerFaceColor',orange)
hold on
plot(x,yr2,'-.','LineWidth',1.2,'MarkerEdgeColor',orange,'MarkerFaceColor',orange)
ylabel('$\omega^2$','Interpreter','latex')
h=legend('$\beta=I$','$\beta=1.05I$','Location', 'northeast');
set(h,'Interpreter','latex');
grid