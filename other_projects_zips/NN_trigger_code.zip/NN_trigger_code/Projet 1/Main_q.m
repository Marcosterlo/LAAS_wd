clear all
clc
%% parameters
g = 10; % gravitational coefficient
m = 0.15; % mass
l = 0.5; % length
mu = 0.05; % frictional coefficient
dt = 0.02; % sampling period

%% x^+ = AG*x + BG1*q + BG2*u
sysP.AG = [1,      dt;...
      g/l*dt, 1-mu/(m*l^2)*dt];
% describes how q enters the system
sysP.BG1 = [0;...
       -g/l*dt];
% describes how u enters the system
sysP.BG2 = [0;...
      dt/(m*l^2)];
sysP.nG = size(sysP.AG, 1);
nu = 1;
nq = 1;

%  v_Delta = CG*xG + [DG1 DG2]*[q; u] = xG
CG = [1, 0];
DG1 = 0;
DG2 = 0; 

%% load weights and biases of the NN controller     
%fname = '../vehicle_training/Wb_s32_tanh/';
fname = 'Wb_s32_tanh/';
load([fname 'W1.csv'])
load([fname 'W2.csv'])
load([fname 'W3.csv'])
W{1} = W1;
W{2} = W2;
W{3} = W3;

% load('file_W3_ini.mat')

nlayer = numel(W)-1;

b = cell(1,nlayer);
n = zeros(1,nlayer);
for i=1:nlayer+1
    n(i) = size(W{i},1);
    b{i} = zeros(n(i),1);
    sysC.W{i} = W{i};
    sysC.b{i} = b{i};
end
nphi = sum(n(1:nlayer));

xeq = [0.0; 0.0];
veq = cell(1,nlayer);
weq = cell(1,nlayer);
vup = cell(1,nlayer);
vlb = cell(1,nlayer);
wup = cell(1,nlayer);
wlb = cell(1,nlayer);
alpha = cell(1,nlayer);

veq{1} = W{1}*xeq + b{1};
weq{1} = tanh(veq{1});
for i = 2:nlayer
    veq{i} = W{i}*weq{i-1} + b{i};
    weq{i} = tanh(veq{i});
end

deltav1 = 0.5;
vup{1} = deltav1 + veq{1};
vlb{1} = veq{1} - deltav1;
% 
beta = 1;
up = 0;
lb = 0;
Alpha = [];

alpha{1} = min((tanh(vup{1})-tanh(veq{1}))./(vup{1}-veq{1}), (tanh(veq{1})-tanh(vlb{1}))./(veq{1}-vlb{1}));
wup{1} = tanh(vup{1});
wlb{1} = tanh(vlb{1});
for i = 1:nlayer
    if i>1
        for j = 1:n(i)
            up = W{i}(j,:)*1/2*(wup{i-1}+wlb{i-1}) + b{i}(j) + abs(W{i}(j,:))*1/2*abs(wup{i-1}-wlb{i-1});
            lb = W{i}(j,:)*1/2*(wup{i-1}+wlb{i-1}) + b{i}(j) - abs(W{i}(j,:))*1/2*abs(wup{i-1}-wlb{i-1});
            vup{i} = [vup{i}; up];
            vlb{i} = [vlb{i}; lb];
        end
        alpha{i} = min((tanh(vup{i})-tanh(veq{i}))./(vup{i}-veq{i}), (tanh(veq{i})-tanh(vlb{i}))./(veq{i}-vlb{i}));
        wup{i} = tanh(vup{i});
        wlb{i} = tanh(vlb{i});
    end
    Alpha = blkdiag(Alpha,diag(alpha{i}));
end
Beta = beta*eye(nphi);

      
%% Define IQCs for the nonlinearity x1 - sin(x1)
% x1 - sin(x1) is slope-restricted in [0, 2] globally ---> off-by-one IQC

% x1 - sin(x1) is sector-bounded in [0, 1.22] globally ---> sector IQC
% x1 - sin(x1) is sector-bounded in [0, 1] locally on x1 in [-pi,pi]
% x1 - sin(x1) is sector-bounded in [0, 0.7606] locally on x1 in [-2.5,2.5]
% define the filter for off-by-one IQC
%L_slope = 2;
x1bound = 2.5;
L_slope = 1 - cos(x1bound);
m_slope = 0;
Apsi = 0;
sysP.nxi = size(Apsi,1);
Apsi = Apsi*dt + eye(sysP.nxi);
Bpsi1 = -L_slope;
Bpsi2 = 1;
Bpsi1 = Bpsi1*dt;
Bpsi2 = Bpsi2*dt;
Cpsi = [1; 0];
Dpsi1 = [L_slope; -m_slope];
Dpsi2 = [-1; 1];
     
%% construct the extended system
sysP.A = [sysP.AG, zeros(sysP.nG,sysP.nxi);...
        Bpsi1*CG, Apsi];
sysP.Bq = [sysP.BG1;
        Bpsi1*DG1+Bpsi2];
sysP.Bu = [sysP.BG2;    
        Bpsi1*DG2];
sysP.C = [Dpsi1*CG, Cpsi];
sysP.Dq = Dpsi1*DG1+Dpsi2;
sysP.Du = Dpsi1*DG2;
sysP.nzeta = sysP.nG + sysP.nxi;     

%% Convex Optimization - compute trigger parameters and ROA

%[sol,solPb] = code_NN_q(sysP,sysC,Alpha,Beta)

%[sol,solPb] = code_NN_trigger_q(sysP,sysC,Alpha,Beta)

[sol,solPb] = code_NN_trigger_wq(sysP,sysC,Alpha,Beta)

%[sol,solPb] = code_NN_trigger_wxq(sysP,sysC,Alpha,Beta)

%% plot results
% Simulation results
Nstep = 500;
[vet val] = eig(sol.P(1:2,1:2));
% x0 = 1/val(1,1)*vet(:,1);
x0 = 1/val(2,2)*vet(:,2);

%[x,u,update] = NN_trigger_closedloop(Nstep,x0,{W1,W2,W3},{b1,b2,b3},sol.Qe,sol.Qx,g,m,l,mu,dt);

for i = 1:size(pts,2)
    [x,u,update,sumup] = NN_trigger_w_closedloop(Nstep,sysP,x0,W,b,sol.Qe,sol.Qw);    
%    [x,u,update,sumup] = NN_trigger_wx_closedloop(Nstep,x0,{W1,W2,W3},{b1,b2,b3},sol.Qex,sol.Qew,sol.Qx,sol.Qw,g,m,l,mu,dt);
    if sumup(1)~=sumup(2)
        sumup
    end
end

k = 1:1:Nstep;

% states
figure(1)

subplot(2,1,1)
stairs(k,x(1,2:end),'Color','b','LineStyle','-','LineWidth',1.2);
hold on
stairs(k,x(2,2:end),'Color','g','LineStyle','-','LineWidth',1.2);
set(gca,'Ticklabelinterpreter','latex')
xlabel('$k$' ,'interpreter','latex')
ylabel('$x_k$','interpreter','latex');
h=legend( '$x_1$','$x_2$','Location', 'northeast');
set(h,'Interpreter','latex');
grid

% control 
subplot(2,1,2)
stairs(k,u(1,1:end),'Color','r','LineStyle','-','LineWidth',1.2);
set(gca,'Ticklabelinterpreter','latex')
xlabel('$k$' ,'interpreter','latex')
ylabel('$u_k$','interpreter','latex');
h=legend( '$u_k$','Location', 'northeast');
set(h,'Interpreter','latex');
grid
% inter-events
% 
% figure(2)
% subplot(2,1,1)
% aux = 1;
% for i = 2:Nstep
%     if update(i)~= 0
%         stem((i-2)*dt, i-aux-1,'b.','MarkerFaceColor','auto');
%         aux = i;
%         hold on
%     end
% end
% xlabel('$k$' ,'interpreter','latex')
% ylabel('Inter-events','interpreter','latex');
% grid

figure(2)
aux = zeros(2,1);
for k = 2:Nstep
    for i = 1:2
        if update(i,k)== 1
            subplot(2,1,i)
            stem(k-2, k-aux(i)-1,'LineStyle','-','Color','m','Marker','s','MarkerSize',3, 'MarkerFaceColor','auto');
            aux(i) = k;
            hold on
        end
    end
end

% ROA
figure(3)
x1 = linspace(-1,1,100);
x2 = linspace(-1.5,1.5,100);
for i = 1:100
    a = 1;
    for j =1:100
        V = [x1(i),x2(j)]*sol.P(1:nG,1:nG)*[x1(i);x2(j)];
        if V <=1
            plot(x1(i),x2(j),'.','color','b' );
            hold on
            pts(:,a) = [x1(i);x2(j)];
            a = a+1;
        end
    end
end

[U D V] = svd(sol.P(1:2,1:2));

a = 1/sqrt(D(1,1));
b = 1/sqrt(D(2,2));
theta = [0:1/20:2*pi+1/20];

state(1,:) = a*cos(theta); 
state(2,:) = b*sin(theta);

X = V * state;
hold on
plot(X(1,:),X(2,:),'Color','b','LineWidth',2,'LineStyle' ,'-');

x1 = linspace(-1.5,1.5,1e3);
for i=1:n1
    plot(x1,(deltav1-W1(i,1)*x1)/W1(i,2),'color',mycolor('orange')) 
    plot(x1,(-deltav1-W1(i,1)*x1)/W1(i,2),'color',mycolor('orange'))
    hold on;
end
xlabel('$x_1$','interpreter','latex')
ylabel('$x_2$','interpreter','latex');
grid

%%%
% W1 = double(W11);
% W2 = double(W22);
% W3 = double(W33);
% W4 = double(W44);
% 
% n1 = size(W1,1);
% n2 = size(W2,1);
% n3 = size(W3,1);
% n4 = size(W4,1);
% nphi = n1+n2+n3;
% 
% b1 = zeros(n1,1);
% b2 = zeros(n2,1);
% b3 = zeros(n3,1);
% b4 = zeros(n4,1);
% 
% sysC.W1 = W1;
% sysC.W2 = W2;
% sysC.W3 = W3;
% sysC.W4 = W4;
% 
% sysC.b1 = b1;
% sysC.b2 = b2;
% sysC.b3 = b3;
% sysC.b4 = b4;

% xeq = [0.0; 0.0];
% v1eq = W1*xeq + b1;
% w1eq = tanh(v1eq);
% v2eq = W2*w1eq + b2;
% w2eq = tanh(v2eq);
% v3eq = W3*w2eq + b3; % This is also u_*
% w3eq = tanh(v3eq);
% v4eq = W4*w3eq + b4; % This is also u_*
% % usat = sat(v3) = sat(u)
% 
% deltav1 = 0.5;
% v1up = deltav1 + v1eq;
% v1lb = v1eq - deltav1;
% 
% % 
% alpha1 = min((tanh(v1up)-tanh(v1eq))./(v1up-v1eq), (tanh(v1eq)-tanh(v1lb))./(v1eq-v1lb));
% beta = 1;
% w1up = tanh(v1up);
% w1lb = tanh(v1lb);
% 
% v2up = [];
% v2lb = [];
% for i = 1:n2
%     v2up_i = W2(i,:)*1/2*(w1up+w1lb) + b2(i) + abs(W2(i,:))*1/2*abs(w1up-w1lb);
%     v2lb_i = W2(i,:)*1/2*(w1up+w1lb) + b2(i) - abs(W2(i,:))*1/2*abs(w1up-w1lb);
%     v2up = [v2up; v2up_i];
%     v2lb = [v2lb; v2lb_i];
% end
% 
% alpha2 = min((tanh(v2up)-tanh(v2eq))./(v2up-v2eq), (tanh(v2eq)-tanh(v2lb))./(v2eq-v2lb));
% w2up = tanh(v2up);
% w2lb = tanh(v2lb);
% 
% v3up = [];
% v3lb = [];
% for i = 1:n3
%     v3up_i = W3(i,:)*1/2*(w2up+w2lb) + b3(i) + abs(W3(i,:))*1/2*abs(w2up-w2lb);
%     v3lb_i = W3(i,:)*1/2*(w2up+w2lb) + b3(i) - abs(W3(i,:))*1/2*abs(w2up-w2lb);
%     v3up = [v3up; v3up_i];
%     v3lb = [v3lb; v3lb_i];
% end
% 
% alpha3 = min((tanh(v3up)-tanh(v3eq))./(v3up-v3eq), (tanh(v3eq)-tanh(v3lb))./(v3eq-v3lb));
% 
% Alpha = blkdiag(diag(alpha1),diag(alpha2),diag(alpha3));
% Beta = beta*eye(nphi);