function [x,u, update] = NN_trigger_closedloop(Nstep,x0,W,b,Qe,Qx,g,m,l,mu,dt)
% Simulate system for N steps from the initial condition x0.
%
% Syntax for linear plant: x(k+1) = Ad x(k) + Bd u(k)
%   [x,u] = nnclosedloop(N,x0,W,b,Ad,Bd)  

% Initialize outputs

Nx = numel(x0);

x = zeros(Nx,Nstep);
x(:,2) = x0;

xh = zeros(Nx,Nstep);

update = zeros(1,Nstep);

if (xh(:,1)-x(:,2))'*Qe*(xh(:,1)-x(:,2))> x(:,2)'*Qx*x(:,2)
    xh(:,2) = x(:,2);
else
    xh(:,2) = xh(:,1);
 end

u0 = LOCALnn(xh(:,2),W,b);
Nu = numel(u0);

u = zeros(Nu,Nstep);
u(:,2) = u0;

% Simulate System
% nin = nargin;
for i = 3:Nstep
%     if nin==6 

      x(:,i) = x(:,i-1)+[x(2,i-1);...
                           g/l*sin(x(1,i-1))-mu/(m*l^2)*x(2,i-1)+1/(m*l^2)*u(:,i-1)]*dt;
                       
      if (xh(:,i-1)-x(:,i))'*Qe*(xh(:,i-1)-x(:,i))> x(:,i)'*Qx*x(:,i)
          xh(:,i) = x(:,i);
          update(i) = i;
      else
          xh(:,i) = xh(:,i-1);
          update(i) = 0;
      end
%         x(:,i) = Ad*x(:,i-1)+Bd*u(:,i-1);
%     else
%         fh = Ad;
%         x(:,i) = fh( x(:,i-1), u(:,i-1) );
%     end
    
    u(:,i) = LOCALnn(xh(:,i),W,b);
end


%%
% LOCAL Function to evaluate the Neural Network
function u = LOCALnn(xh,W,b)
    
Nlayer = numel(W);
z = xh;
for i=1:(Nlayer-1)
    z = W{i}*z + b{i};
    
    % XXX - Nonlinearity could be input as a function handle
    z = tanh(z);
end
u = W{end}*z+b{end};
    
