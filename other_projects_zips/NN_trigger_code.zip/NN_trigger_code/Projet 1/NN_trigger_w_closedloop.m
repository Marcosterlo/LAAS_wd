function [x,u,update,sumup,erro_next] = NN_trigger_w_closedloop(Nstep,sysP,x0,W,b,Qet,Qwt)
% Simulate system for N steps from the initial condition x0.
%
% Syntax for linear plant: x(k+1) = Ad x(k) + Bd u(k)
%   [x,u] = nnclosedloop(N,x0,W,b,Ad,Bd)

A = sysP.AG;
Bu = sysP.BG2;

% Initialize outputs
nlayer = numel(W)-1;
n = zeros(1,nlayer);
for i=1:nlayer
    n(i) = size(W{i},1);
end
nG = size(sysP.AG,1);
% Qe = cell(1,nlayer);
% Qw = cell(1,nlayer);
% for i = 1:nlayer
%     Qe{i} = Qet(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
%     Qw{i} = Qwt(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
% end

Qe = cell(1,nlayer);
Qw = cell(1,nlayer);
Qwx = cell(1,nlayer);
for i = 1:nlayer
    Qe{i} = Qet(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
    Qw{i} = Qwt(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
end
Qwx{1} = Qwt(1+sum(n(1:2)):sum(n(1:2))+nG,1+sum(n(1:2)):sum(n(1:2))+nG);
Qwx{2} = Qwt(1+sum(n(1:2))+nG:end,1+sum(n(1:2))+nG:end);

Nx = numel(x0);

x = zeros(Nx,Nstep);
x(:,2) = x0;

w = cell(nlayer+1,1);
w{1,1} =  zeros(Nx,1);
wh{1,1} = zeros(Nx,1);
erro = zeros(nlayer,Nstep);
erro_next = cell(1,nlayer);
for i = 2:nlayer+1
    w{i,1} = zeros(n(i-1),1);
    wh{i,1} = zeros(n(i-1),1);
    erro_next{i} = zeros(1,i-1);
end

Nu = size(W{end},1);
u = zeros(Nu,Nstep);

update = zeros(nlayer,Nstep);
sumup = zeros(nlayer,1);

theta = zeros(nlayer,Nstep);

% Simulate System
for k = 2:Nstep
    
    flag = 0;
    
    cont = 0;
    
    [th] = calcula_theta(n, nlayer, x(:,k), {wh{2,k-1},wh{3,k-1}}, W, b, Qe, Qw, Qwx);
    
    theta(:,k) = th;
    
    wh{1,k} = x(:,k); 
    
    while flag == 0
        
        for i = 1:nlayer
            
            w{i+1,k} = tanh(W{i}*wh{i,k} + b{i});
            
            erro(i,k) = (wh{i+1,k-1}-w{i+1,k})'*Qe{i}*(wh{i+1,k-1}-w{i+1,k}) - w{i+1,k}'*Qw{i}*w{i+1,k} - wh{i,k}'*Qwx{i}*wh{i,k};
            if erro(i,k) > 0%theta(i,k)%
                wh{i+1,k} = w{i+1,k};
                update(i,k) = 1;
            else
                wh{i+1,k} = wh{i+1,k-1};
                update(i,k) = 0;
            end
        end
        
        if cont == 0
            [theta_new] = avalia_theta(nlayer, theta(:,k), x(:,k), {w{2,k},w{3,k}}, {wh{2,k},wh{3,k}}, Qe, Qw, Qwx);
        end
        if theta_new == theta(:,k)
            flag = 1;
        else
            theta(:,k) = theta_new;
            cont = 1;
        end
        
    end
    
    u(:,k) = W{end}*wh{end,k}+b{end};
    
%     x(:,k+1) = x(:,k)+[x(2,k);...
%         g/l*sin(x(1,k))-mu/(m*l^2)*x(2,k)+1/(m*l^2)*u(:,k)]*dt;
     x(:,k+1) = A*x(:,k)+Bu*u(:,k);%+Bq*(x(1,k)-sin(x(1,k)));
    
end
for i=1:nlayer
   sumup(i) = sum(update(i,:));
end
%         aux = min([abs((erro_w1_p-erro_w2_pn)/2),abs((erro_w1_p-erro_w2_ps)/2)]);
%     if erro_w1_p> 0
%         theta(1,k+1) = aux;
%         theta(2,k+1) = -theta(1,k+1);
%     else %if erro_w1_p< 0 && (erro_w1_p/erro_w2_pn>0)
%         theta(1,k+1) = -aux;
%         theta(2,k+1) = -theta(1,k+1);
% %     else
% %         theta(1,k+1) = 0;
% %         theta(2,k+1) = 0;
%     end
end

%%
% if k>2
%     if (erro_next{2}/erro_next{3}(:,2)>0) && (erro_next{2}>0)
%         theta(1,k) = 1.01*erro_next{2};
%         theta(2,k) = - theta(1,k);
%     elseif (erro_next{2}/erro_next{3}(:,2)>0) && (erro_next{2}<0)
%         theta(1,k) = 0;
%         theta(2,k) = 0;
%     elseif(erro_next{2}/erro_next{3}(:,2)<0) && (erro_next{2}>erro_next{3}(:,2))
%         theta(1,k) = -1.01*erro_next{3}(:,1);
%         theta(2,k) = - theta(1,k);
%     elseif  (erro_next{2}/erro_next{3}(:,2)<0) && (erro_next{2}<erro_next{3}(:,2))
%         theta(1,k) = 0;
%         theta(2,k) = 0;
%     end
% end


