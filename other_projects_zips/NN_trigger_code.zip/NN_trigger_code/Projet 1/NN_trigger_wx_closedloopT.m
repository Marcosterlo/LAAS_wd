function [x,u,update,sumup,vet_error] = NN_trigger_wx_closedloopT(Nstep,x0,W,b,Qex,Qew,Qx,Qw,g,m,l,mu,dt)
% Simulate system for N steps from the initial condition x0.
%
% Syntax for linear plant: x(k+1) = Ad x(k) + Bd u(k)
%   [x,u] = nnclosedloop(N,x0,W,b,Ad,Bd)

% Initialize outputs
Nlayer = numel(W);
n1 = size(W{1},1);
n2 = size(W{2},1);
nG = 2;

Qew1 = Qew(1:n1,1:n1);
Qew2 = Qew(n1+1:end,n1+1:end);

% Qw1 = Qw(1:n1,1:n1);
% Qw2 = Qw(n1+1:end,n1+1:end);
Qwx = Qw(1:nG,1:nG);
Qw1 = Qw(nG+1:nG+n1,nG+1:nG+n1);
Qw12 = Qw(nG+n1+1:nG+2*n1,nG+n1+1:nG+2*n1);
Qw2 = Qw(2*n1+nG+1:end,2*n1+nG+1:end);

Nx = numel(x0);

x = zeros(Nx,Nstep);
xh = zeros(Nx,Nstep);
x(:,2) = x0;

w = cell(Nlayer,Nstep);
w{1,1} = zeros(Nx,1);
w{2,1} = zeros(n1,1);
w{3,1} = zeros(n2,1);

wh = cell(Nlayer,Nstep);
wh{1,1} = zeros(Nx,1);
wh{2,1} = zeros(n1,1);
wh{3,1} = zeros(n2,1);

Nu = size(W{end},1);
u = zeros(Nu,Nstep);

update = zeros(3,Nstep);
sumup = zeros(3,1);

theta = [zeros(1,Nstep);zeros(1,Nstep);zeros(1,Nstep)];
erro_x = zeros(1,Nstep);
erro_w1 = zeros(1,Nstep);
erro_w2 = zeros(1,Nstep);


vet_error = double.empty;
% Simulate System
for k = 2:Nstep
    
    erro_x_p = (xh(:,k-1)-x(:,k))'*Qex*(xh(:,k-1)-x(:,k))- x(:,k)'*Qx*x(:,k);           
    w{2,k} = tanh(W{1}*x(:,k) + b{1});
    erro_w1_ps = (wh{2,k-1}-w{2,k})'*Qew1*(wh{2,k-1}-w{2,k}) - w{2,k}'*Qw1*w{2,k};
    w{3,k} = tanh(W{2}*w{2,k} + b{2});
    erro_w2_pss = (wh{3,k-1}-w{3,k})'*Qew2*(wh{3,k-1}-w{3,k}) - w{3,k}'*Qw2*w{3,k}; 
    
    w{2,k} = tanh(W{1}*xh(:,k-1) + b{1});
    erro_w1_pn = (wh{2,k-1}-w{2,k})'*Qew1*(wh{2,k-1}-w{2,k}) - w{2,k}'*Qw1*w{2,k};
    w{3,k} = tanh(W{2}*w{2,k} + b{2});
    erro_w2_pns = (wh{3,k-1}-w{3,k})'*Qew2*(wh{3,k-1}-w{3,k}) - w{3,k}'*Qw2*w{3,k};
    
    w{3,k} = tanh(W{2}*wh{2,k-1} + b{2});
    erro_w2_pn = (wh{3,k-1}-w{3,k})'*Qew2*(wh{3,k-1}-w{3,k}) - w{3,k}'*Qw2*w{3,k};
    
    vet_error = [vet_error,[erro_x_p;erro_w1_ps;erro_w1_pn;erro_w2_pss;erro_w2_pns;erro_w2_pn]];
    
    if (erro_x_p/erro_w1_pn>0) && (erro_x_p>0) && (erro_w1_pn~=0) %(erro_w1_p/erro_w2_pn>0) && (erro_w1_p>0) && (erro_w2_pn~=0)
        theta(3,k) = 1.01*erro_x_p;
        theta(1,k) = - theta(3,k); 
        theta(2,k) = 0;
    elseif(erro_x_p/erro_w1_pn<0) && (erro_x_p>erro_w1_pn) 
        theta(3,k) = -1.01*erro_w1_ps;
        theta(1,k) = - theta(3,k);
        theta(2,k) = 0;
        else
        theta(3,k) = 0;
        theta(1,k) = 0;
        theta(2,k) = 0;
     end
            
%     if (erro_x_p/erro_w1_pn>0) && (erro_x_p>0) && (erro_w1_pn~=0)
%         theta(3,k) =    1.01*erro_x_p;                                   %não
%         theta(1,k) =  -(theta(3,k)+theta(2,k));                          %sim
%         theta(2,k) =    1.01*erro_w2_pns;                                %não
%     elseif(erro_x_p/erro_w1_pn<0) && (erro_x_p>0) && (erro_w2_pn<0)
%         theta(3,k) = -1.01*erro_w1_ps;  % sim
%         theta(1,k) =  -theta(3,k);      % não
%         theta(2,k) =  0;                % não
%     elseif(erro_x_p/erro_w1_pn<0) && (erro_x_p>0) && (erro_w2_pn>0) 
%         theta(3,k) = 1.01*erro_x_p; %não         
%         theta(1,k) = 0;             %não       
%         theta(2,k) = -theta(3,k);   %sim          
%     elseif  (erro_x_p/erro_w1_pn<0) && (erro_x_p<0)
%         theta(3,k) = 0;                %não
%         theta(1,k) =1.01*erro_w1_pn;   %não
%         theta(2,k) = -theta(1,k);      %sim
%     else       
%         theta(3,k) = 0; %não
%         theta(1,k) = 0; %não
%         theta(2,k) = 0; %não
%     end
    
    
    erro_x(k) = (xh(:,k-1)-x(:,k))'*Qex*(xh(:,k-1)-x(:,k))- x(:,k)'*Qx*x(:,k);
    if erro_x(k) > theta(3,k)
        xh(:,k) = x(:,k);
        update(3,k) = 1;
        sumup(3) = sumup(3) + 1;
    else
        xh(:,k) = xh(:,k-1);
        update(3,k) = 0;
    end
    
    wh{1,k} = xh(:,k); 
    
    for i = 2:Nlayer
        
        w{i,k} = tanh(W{i-1}*wh{i-1,k} + b{i-1});
            
        if i == 2
            erro_w1(k) = (wh{2,k-1}-w{2,k})'*Qew1*(wh{2,k-1}-w{2,k}) - w{2,k}'*Qw1*w{2,k}; 
            if erro_w1(k) > theta(1,k)%
                wh{2,k} = w{2,k};
                update(1,k) = 1;
                sumup(1) = sumup(1) + 1;
            else
                wh{2,k} = wh{2,k-1};
                update(1,k) = 0;
            end
        else
            erro_w2(k) = (wh{3,k-1}-w{3,k})'*Qew2*(wh{3,k-1}-w{3,k})- w{3,k}'*Qw2*w{3,k};
            if erro_w2(k) > theta(2,k)%
                wh{3,k} = w{3,k};
                update(2,k) = 1;
                sumup(2) = sumup(2) + 1;
             else
                wh{3,k} = wh{3,k-1};
                update(2,k) = 0;
            end
        end
    end
    
    u(:,k) = W{end}*wh{Nlayer,k}+b{end};
    
    x(:,k+1) = x(:,k)+[x(2,k);...
        g/l*sin(x(1,k))-mu/(m*l^2)*x(2,k)+1/(m*l^2)*u(:,k)]*dt;
     
end
end

