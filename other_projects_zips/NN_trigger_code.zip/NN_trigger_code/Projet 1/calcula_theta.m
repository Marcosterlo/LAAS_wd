function [theta] = calcula_theta(n, nlayer, x, wh, W, b, Qe, Qw, Qwx)

nG = size(x,1);
w = cell(nlayer,1);
erro_next = cell(1,nlayer);
for i = 1:nlayer
    w{i} = zeros(n(i),1);
    erro_next{i} = zeros(1,i);
end

wopt = cell(1,nlayer);
w{1} = tanh(W{1}*x + b{1});
erro_next{1} = (wh{1}-w{1})'*Qe{1}*(wh{1}-w{1}) - w{1}'*Qw{1}*w{1} - x'*Qwx{1}*x;
wopt{1} = [w{1},wh{1}];
for i = 2:nlayer
    for j = 1:2
        w{i} = tanh(W{i}*wopt{i-1}(:,j) + b{i});
        erro_next{i}(:,j) = (wh{i}-w{i})'*Qe{i}*(wh{i}-w{i}) - w{i}'*Qw{i}*w{i} - wopt{i-1}(:,j)'*Qwx{i}*wopt{i-1}(:,j);
        wopt{i} = [wopt{i},w{i}];
    end
end

delta  = [];
for i = 1:nlayer
    for j= i+1:nlayer
        aux = [];
        for s = 1:size(erro_next{j},2)
            aux = [aux, erro_next{i}-erro_next{j}(:,s)];
        end
        delta = [delta, min(aux)];%min(aux)*min(abs(aux))/max(abs(aux)) + max(aux)*min(abs(aux))/max(abs(aux))
    end
end
theta = inv([1 1;1 -1])*[0;delta(1)];
%    theta(:,k) = inv([1 1 1;1 -1 0;1 0 -1])*[0;delta(1);delta(2)];
end