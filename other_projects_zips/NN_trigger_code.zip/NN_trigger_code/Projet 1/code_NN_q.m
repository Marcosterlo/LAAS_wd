function [sol,solPb] = code_NN_q(sysP,sysC,alpha,beta)

pbLMI = [];

nG = sysP.nG;
nxi = sysP.nxi;
nzeta = sysP.nzeta;
nu = 1;
nq = 1;

nlayer = numel(sysC.W)-1;

N = [];
n = zeros(1,nlayer);
W = cell(1,nlayer);
for i=1:nlayer+1
    W{i} = sysC.W{i};
    n(i) = size(W{i},1);
    N = blkdiag(N,W{i});
end
nphi = sum(n(1:nlayer));
Nux = N(nphi+1:end,1:nG);
Nuw = N(nphi+1:end,nG+1:end);
Nvx = N(1:nphi,1:nG);
Nvw = N(1:nphi,nG+1:end);
Nuzeta = [Nux, zeros(nu,nxi)];
Nvzeta = [Nvx, zeros(nphi,nxi)];

% M matrix for off-by-one IQC 
M_off = [0, 1;
         1, 0];
% define the filter for sector IQC
%L_sector = 0.7606;
x1bound = 2.5;
L_sector = (x1bound - sin(x1bound))/x1bound;
m_sector = 0;
Psi_sec = [L_sector, -1;...
           -m_sector,    1];
% M matrix for sector IQC
M_sec = [0, 1;...
         1, 0];    

%%
% Definition des variables et du systeme de LMIs a contruire
P = sdpvar(nzeta,nzeta,'symmetric');   
pbLMI = pbLMI + (P>=0);
T = sdpvar(nphi,nphi,'diagonal');
pbLMI = pbLMI + (T>=0);
lambda1 = sdpvar(1,1);
pbLMI = pbLMI + (lambda1>=0);
lambda2 = sdpvar(1,1);
pbLMI = pbLMI + (lambda2>=0);
var = sdpvar(1,1);
pbLMI = pbLMI + (var>=0);

Rphi = [Nvzeta Nvw zeros(nphi,nq);
        zeros(nphi,nzeta) eye(nphi) zeros(nphi,nq)];
  
Mphi = [-2*alpha*beta*T  (alpha+beta)*T;
        (alpha+beta)*T -2*T];  
    
Qphi = Rphi'*Mphi*Rphi;    
  
lmi11 = (sysP.A+sysP.Bu*Nuzeta)'*P*(sysP.A+sysP.Bu*Nuzeta)-P; 
lmi12 = (sysP.A+sysP.Bu*Nuzeta)'*P*sysP.Bu*Nuw;
lmi13 = (sysP.A+sysP.Bu*Nuzeta)'*P*sysP.Bq;
lmi22 = Nuw'*sysP.Bu'*P*sysP.Bu*Nuw;
lmi23 = Nuw'*sysP.Bu'*P*sysP.Bq;
lmi33 = sysP.Bq'*P*sysP.Bq;

QV = [lmi11  lmi12  lmi13;
         lmi12' lmi22  lmi23;
         lmi13' lmi23' lmi33];  
     
Qoff = lambda2*[sysP.C+sysP.Du*Nuzeta sysP.Du*Nuw sysP.Dq]'...
    *M_off*[sysP.C+sysP.Du*Nuzeta sysP.Du*Nuw sysP.Dq];     

R_sec = [eye(1,1),zeros(1,1+nxi+nphi+nq);...
       zeros(nq,nzeta+nphi),eye(nq)];
Qsec = lambda1*R_sec'*Psi_sec'*M_sec*Psi_sec*R_sec;

MSTAB = Qoff + QV + Qsec + Qphi;

D = blkdiag(eye(nG,nG), eye(nxi,nxi), eye(nphi), eye(nq,nq));

pbLMI = pbLMI + (MSTAB<= 0);% +(D'*MSTAB*D>=-var*eye(nzeta+nphi+nG+nq));
    
deltav1 = 0.1;
lmi111 = deltav1^2;
lmi122 = P;
for i = 1:n(1)
    lmi112 = [W{1}(i,:) zeros(1,nxi)];
    MSETOR = [lmi111 lmi112;
    lmi112' lmi122];
end
pbLMI = pbLMI + (MSETOR>=0);
% 
lmi211 = x1bound^2;
lmi212 = [1,0, zeros(1,nxi)];
lmi222 = P;
MSETOR2 = [lmi211 lmi212;
    lmi212' lmi222];
pbLMI = pbLMI + (MSETOR2>=0);

% critere d'optimisation
critOPTIM = [];%trace(P(1:nG,1:nG))+trace(Qe)-trace(Qx);

% les options d'optimisation
% --------------------------
options_sdp = sdpsettings('verbose',0,'warning',0,'solver','sdpt3');
options_sdp.sdpt3.maxit    = 100;
options_sdp.lmilab.maxiter = 500;    % default = 100
options_sdp.lmilab.reltol = 0.001;    % default = 0.01?? in lmilab 1e-03
options_sdp.lmilab.feasradius = 1e9; % R<0 signifie "no bound", default = 1e9


% resolution du probleme
solPb = solvesdp(pbLMI,critOPTIM,options_sdp);
%solPb = optimize(pbLMI,critOPTIM,options_sdp);

feasible = min(checkset(pbLMI));
if (feasible >= 0) % && solPb.problem == 0)
    sol.P = double(P);
else
    sol.P = [];
end

end