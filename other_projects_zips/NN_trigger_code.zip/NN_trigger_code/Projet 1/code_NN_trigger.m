function [sol,solPb] = code_NN_trigger(sysP,sysC,alpha,beta)

pbLMI = [];

AG = sysP.A;
BG = sysP.B;
W1 = sysC.W1;
W2 = sysC.W2;
W3 = sysC.W3;

nG = size(AG,1);
n1 = size(W1,1);
n2 = size(W2,1);
nphi = n1+n2;

N = blkdiag(W1,W2,W3);
Nux = N(n1+n2+1:end, 1:nG);
Nuw = N(n1+n2+1:end,nG+1:end);
Nvx = N(1:n1+n2, 1:nG);
Nvw = N(1:n1+n2,nG+1:end);

%%

% Definition des variables et du systeme de LMIs a contruire
P = sdpvar(nG,nG,'symmetric');   
pbLMI = pbLMI + (P>=0);
Qe = sdpvar(nG,nG,'symmetric');   
pbLMI = pbLMI + (Qe>=0);
Qx = sdpvar(nG,nG,'symmetric');   
pbLMI = pbLMI + (Qx>=0);
T = sdpvar(nphi,nphi,'diagonal');
pbLMI = pbLMI + (T>=0);
var = sdpvar(1,1,'full');
pbLMI = pbLMI + (var>=0);

Rphi = [Nvx Nvw Nvx;
        zeros(nphi,nG) eye(nphi) zeros(nphi,nG)];
  
Mphi = [-2*alpha*beta*T  (alpha+beta)*T ;
        (alpha+beta)*T -2*T];   
    
Qphi = Rphi'*Mphi*Rphi;

lmi11 = (AG+BG*Nux)'*P*(AG+BG*Nux)-P+Qx; 
lmi12 = (AG+BG*Nux)'*P*BG*Nuw;
lmi13 = (AG+BG*Nux)'*P*BG*Nux;
lmi22 = Nuw'*BG'*P*BG*Nuw;
lmi23 = Nuw'*BG'*P*BG*Nux;
lmi33 = Nux'*BG'*P*BG*Nux-Qe;

QV = [lmi11  lmi12  lmi13;
         lmi12' lmi22  lmi23;
         lmi13' lmi23' lmi33];
 
MSTAB = QV + Qphi;

D = blkdiag(eye(nG,nG), eye(nphi), eye(nG,nG));

pbLMI = pbLMI + (MSTAB<= 0);% +(D'*MSTAB*D>=-var*eye(2*nG+nphi));

deltav1 = 0.5;
lmi111 = deltav1^2;
lmi122 = P;
for i = 1:n1
    lmi112 = W1(i,:);
    MSETOR = [lmi111 lmi112;
    lmi112' lmi122];
end
pbLMI = pbLMI + (MSETOR>=0);

x1bound = 2.5;
lmi211 = x1bound^2;
lmi212 = [1,0];
lmi222 = P;
MSETOR2 = [lmi211 lmi212;
    lmi212' lmi222];
pbLMI = pbLMI + (MSETOR2>=0);

% critere d'optimisation
critOPTIM = trace(P)+trace(Qe)-trace(Qx);

% les options d'optimisation
% --------------------------
options_sdp = sdpsettings('verbose',0,'warning',0,'solver','sdpt3');
options_sdp.sdpt3.maxit    = 100;
options_sdp.lmilab.maxiter = 500;    % default = 100
options_sdp.lmilab.reltol = 0.001;    % default = 0.01?? in lmilab 1e-03
options_sdp.lmilab.feasradius = 1e9; % R<0 signifie "no bound", default = 1e9


% resolution du probleme
solPb = solvesdp(pbLMI,critOPTIM,options_sdp);
%solPb = optimize(pbLMI,critOPTIM,options_sdp);

feasible = min(checkset(pbLMI));
if (feasible >= 0) % && solPb.problem == 0)
    sol.P = double(P);
    sol.Qe = double(Qe);
    sol.Qx = double(Qx);
else
    sol.P = [];
    sol.Qe = [];
    sol.Qx = [];
end

end