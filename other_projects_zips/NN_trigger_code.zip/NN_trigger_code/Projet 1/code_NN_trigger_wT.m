function [sol,solPb] = code_NN_trigger_wT(sysP,sysC,alpha,beta)

pbLMI = [];

AG = sysP.A;
BG = sysP.B;
W1 = sysC.W1;
W2 = sysC.W2;
W3 = sysC.W3;
W4 = sysC.W4;

nG = size(AG,1);
n1 = size(W1,1);
n2 = size(W2,1);
n3 = size(W3,1);
n4 = size(W4,1);
nphi = n1+n2+n3;

N = blkdiag(W1,W2,W3,W4);
Nux = N(n1+n2+n3+1:end,1:nG);
Nuw = N(n1+n2+n3+1:end,nG+1:end);
Nvx = N(1:n1+n2+n3,1:nG);
Nvw = N(1:n1+n2+n3,nG+1:end);

%%
% Definition des variables et du systeme de LMIs a contruire
var = sdpvar(1,1,'full');
pbLMI = pbLMI + (var>=0);
P = sdpvar(nG,nG,'symmetric');   
pbLMI = pbLMI + (P>=0);
% Qe = sysC.Qe;
% bn1 = sysC.Qw(1:nG,1:nG);
% Qw = blkdiag(sysC.Qw(nG+1:nG+n1,nG+1:nG+n1)+sysC.Qw(nG+n1+1:nG+2*n1,nG+n1+1:nG+2*n1),sysC.Qw(2*n1+nG+1:end,2*n1+nG+1:end));
% Qw1 = sysC.Qw1;
% D = blkdiag(eye(n1,n1),eye(n2,n2));
Qe = blkdiag(sdpvar(n1,n1,'symmetric'),sdpvar(n2,n2,'symmetric'),sdpvar(n3,n3,'symmetric')); 
pbLMI = pbLMI + (Qe>=0) + (Qe<=1*eye(n1+n2+n3,n1+n2+n3));%sdpvar(1,1)*eye(n1+n2);%

Qw =  blkdiag(sdpvar(n1,n1,'symmetric'),sdpvar(n2,n2,'symmetric'),sdpvar(n3,n3,'symmetric'));%blkdiag(sdpvar(n1,n1,'diagonal'),sdpvar(n2,n2,'diagonal'));%sdpvar(n1+n2,n1+n2,'diagonal'); %blkdiag(sdpvar(n1+n2,n1+n2,'diagonal'),sdpvar(n2,n2,'diagonal')); 
pbLMI = pbLMI + (Qw>=0)+ (Qw(1:n1,1:n1)>=var*eye(n1,n1));
% dn1 = sdpvar(n1,n1,'symmetric');
% pbLMI = pbLMI + (dn1>=0);
% dn2 = sdpvar(n2,n2,'symmetric');
% pbLMI = pbLMI + (dn2>=0);
% bn1 = sdpvar(nG,nG,'symmetric');
% pbLMI = pbLMI + (bn1>=0);
% bn2 = sdpvar(n1,n1,'symmetric');
% pbLMI = pbLMI + (bn2>=0);
% Qw = blkdiag(dn1+bn2,dn2); 
% pbLMI = pbLMI + (blkdiag(dn2,bn2)>=var*eye(n1+n2,n1+n2));
T = sdpvar(nphi,nphi,'diagonal');
pbLMI = pbLMI + (T>=0);

Rphi = [Nvx Nvw Nvw;
        zeros(nphi,nG) eye(nphi) zeros(nphi)];
  
Mphi = [-2*alpha*beta*T  (alpha+beta)*T ;
        (alpha+beta)*T -2*T];  

Qphi = Rphi'*Mphi*Rphi;    
  
lmi11 = (AG+BG*Nux)'*P*(AG+BG*Nux)-P;% + bn1; 
lmi12 = (AG+BG*Nux)'*P*BG*Nuw;
lmi13 = (AG+BG*Nux)'*P*BG*Nuw;
lmi22 = Nuw'*BG'*P*BG*Nuw + Qw;
lmi23 = Nuw'*BG'*P*BG*Nuw;
lmi33 = Nuw'*BG'*P*BG*Nuw - Qe;

QV = [lmi11  lmi12  lmi13;
         lmi12' lmi22  lmi23;
         lmi13' lmi23' lmi33];

MSTAB = QV + Qphi;   

D = blkdiag(eye(nG,nG), eye(nphi,nphi),eye(nphi,nphi));

pbLMI = pbLMI + (MSTAB <= 0);%+ (D'*MSTAB*D>=-var*eye(nG+2*nphi));
    
deltav1 = 0.5;
lmi111 = deltav1^2;
lmi122 = P;
for i = 1:n1
    lmi112 = W1(i,:);
    MSETOR = [lmi111 lmi112;
    lmi112' lmi122];
end
pbLMI = pbLMI + (MSETOR>=0);

x1bound = 2.5;
lmi211 = x1bound^2;
lmi212 = [1,0];
lmi222 = P;
MSETOR2 = [lmi211 lmi212;
    lmi212' lmi222];
pbLMI = pbLMI + (MSETOR2>=0);

% critere d'optimisation
critOPTIM = -var;%trace(Qw(1:n1,1:n1));%(n1+1:n1+n2,n1+1:n1+n2)
% les options d'optimisation);%trace(Qw);%%%%
% les options d'optimisation
% --------------------------
options_sdp = sdpsettings('verbose',0,'warning',0,'solver','sdpt3');
options_sdp.sdpt3.maxit    = 100;
options_sdp.lmilab.maxiter = 500;    % default = 100
options_sdp.lmilab.reltol = 0.001;    % default = 0.01?? in lmilab 1e-03
options_sdp.lmilab.feasradius = 1e9; % R<0 signifie "no bound", default = 1e9


% resolution du probleme
solPb = solvesdp(pbLMI,critOPTIM,options_sdp);
%solPb = optimize(pbLMI,critOPTIM,options_sdp);

feasible = min(checkset(pbLMI));
if (feasible >= 0) % && solPb.problem == 0)
    sol.P = double(P);
    sol.Qw =  double(Qw);%double(blkdiag(bn1,dn1,bn2,dn2));%
    sol.Qe = double(Qe);
else
    sol.P = [];
    sol.Qw = [];
    sol.Qe = [];
end

end