function[c,pts_lim] = Grid(Ps,lim,passo)
pts(:,1) = zeros(2,1);
S = double.empty;
a = 1;c = 1;
for x = linspace(-lim(1),lim(1),passo(1))
    b = 1;
    for y = linspace(-lim(2),lim(2),passo(2))
        vetor = [x; y];        
        J = vetor'*Ps*vetor;%
        if J>1
            S(a,b) = 0;
        else
            pts(:,c) = vetor;
            c = c+1;
            S(a,b) = 1;            
        end
        b = b+1;
    end
    a = a+1;
end
pts_lim(:,1:2) = zeros(2,2);
a = 1;b=1;
for i = 1:passo(1)
    k = min(find(S(i,:)));
    j = max(find(S(i,:)));
    if k~= 0
        pts_lim(:,a:a+1) = [pts(:,b) pts(:,b+j-k)];
        a = a+2;
        b = b+j-k+1;
    end
end
end