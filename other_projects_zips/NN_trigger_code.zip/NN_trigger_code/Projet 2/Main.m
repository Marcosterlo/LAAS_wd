clear all
clc
% %% Inverted pendulum
% % parameters
% g = 10; % gravitational coefficient
% m = 0.15; % mass
% l = 0.5; % length
% mu = 0.05; % frictional coefficient
% dt = 0.02; % sampling period
% 
% % x^+ = AG*x + BG*u
% sysP.A = [1,      dt;...
%       g/l*dt, 1-mu/(m*l^2)*dt];
% % describes how u enters the system
% sysP.B = [0;...
%       dt/(m*l^2)];
% sysP.B2 = [0;...
%       -g/l*dt];
% nG = size(sysP.A, 1);
% nu = 1;  
% 
% % load weights and biases of the NN controller     
% fname = 'Wb_s32_tanh/';
% W{1} = load([fname 'W1.csv']);
% W{2} = load([fname 'W2.csv']);
% W{3} = load([fname 'W3.csv'])
% sysC.W = W;
% 
% % load('file_W4_ini.mat')

%% Vehicle lateral control

% parameters
% Nominal speed of the vehicle travels at.
U = 28; % m/s
% Model
% Front cornering stiffness for one wheel.
Ca1 = -61595; % unit: Newtons/rad
% Rear cornering stiffness for one wheel.
Ca3 = -52095; % unit: Newtons/rad

% Front cornering stiffness for two wheels.
Caf = Ca1*2; % unit: Newtons/rad
% Rear cornering stiffness for two wheels.
Car = Ca3*2; % unit: Newtons/rad

% Vehicle mass
m = 1670; % kg
% Moment of inertia
Iz = 2100; % kg/m^2

% Distance from vehicle CG to front axle
a = 0.99; % m
% Distance from vehicle CG to rear axle
b = 1.7; % m

g = 9.81;

% sampling period
dt = 0.01;

% Continuous-time state space matrices
% States are lateral displacement(e) and heading angle error(deltaPsi) and 
% their derivatives.
% Inputs are front wheel angle and curvature of the road.
Ac = [0 1 0 0; ...
      0, (Caf+Car)/(m*U), -(Caf+Car)/m, (a*Caf-b*Car)/(m*U); ...
      0 0 0 1; ...
      0, (a*Caf-b*Car)/(Iz*U), -(a*Caf-b*Car)/Iz, (a^2*Caf+b^2*Car)/(Iz*U)];
B1c = [0; 
      -Caf/m;
      0; ...
      -a*Caf/Iz];

% x^+ = AG*x + BG1*u

sysP.A = Ac*dt + eye(4);

% describes how q enters the system
sysP.B = B1c*dt;

% load weights and biases of the NN controller     
fname = 'Wb_s32_tanh_car/';
W{1} = load([fname 'W1.csv']);
W{2} = load([fname 'W2.csv']);
W{3} = load([fname 'W3.csv']);
sysC.W = W;

%%

nlayer = numel(W)-1;

b = cell(1,nlayer);
n = zeros(1,nlayer);
for i=1:nlayer+1
    n(i) = size(W{i},1);
    b{i} = zeros(n(i),1);
    sysC.W{i} = W{i};
    sysC.b{i} = b{i};
end
nphi = sum(n(1:nlayer));

Alpha = cell(nlayer,1);
for l=1:2
xeq = [0.0; 0.0;0.0;0.0];
veq = cell(1,nlayer);
weq = cell(1,nlayer);
vup = cell(1,nlayer);
vlb = cell(1,nlayer);
wup = cell(1,nlayer);
wlb = cell(1,nlayer);
alpha = cell(1,nlayer);

veq{1} = W{1}*xeq + b{1};
weq{1} = tanh(veq{1});
for i = 2:nlayer
    veq{i} = W{i}*weq{i-1} + b{i};
    weq{i} = tanh(veq{i});
end

deltav1 = [0.6 0.6];
vup{1} = deltav1(l) + veq{1};
vlb{1} = veq{1} - deltav1(l);
% 
beta = 1;
up = 0;
lb = 0;
Alpha{i} = [];

alpha{1} = min((tanh(vup{1})-tanh(veq{1}))./(vup{1}-veq{1}), (tanh(veq{1})-tanh(vlb{1}))./(veq{1}-vlb{1}));
wup{1} = tanh(vup{1});
wlb{1} = tanh(vlb{1});
for i = 1:nlayer
    if i>1
        for j = 1:n(i)
            up = W{i}(j,:)*1/2*(wup{i-1}+wlb{i-1}) + b{i}(j) + abs(W{i}(j,:))*1/2*abs(wup{i-1}-wlb{i-1});
            lb = W{i}(j,:)*1/2*(wup{i-1}+wlb{i-1}) + b{i}(j) - abs(W{i}(j,:))*1/2*abs(wup{i-1}-wlb{i-1});
            vup{i} = [vup{i}; up];
            vlb{i} = [vlb{i}; lb];
        end
        alpha{i} = min((tanh(vup{i})-tanh(veq{i}))./(vup{i}-veq{i}), (tanh(veq{i})-tanh(vlb{i}))./(veq{i}-vlb{i}));
        wup{i} = tanh(vup{i});
        wlb{i} = tanh(vlb{i});
    end
    Alpha{l} = blkdiag(Alpha{l},diag(alpha{i}));
end
end
Beta = beta*eye(nphi);

%% Convex Optimization - compute trigger parameters and ROA

%[sol,solPb] = code_NN_trigger_w(sysP,sysC,Alpha{2},Beta)

[sol,solPb] = code_NN_trigger_wT(sysP,sysC,Alpha{1},Beta,Alpha{2},Beta)

%% plot results
% Simulation results
[vet val] = eig(sol.P);
%x0 = 1/sqrt(val(1,1))*vet(:,1);
x0 = 1/val(2,2)*vet(:,2);

Nstep = 5000;
sumup_traj = zeros(2,1);
sumup_total = zeros(2,1);
for i=1:200
   [x,u,update,sumup,erro] = NN_trigger_w_closedloop(Nstep,sysP,x0,W,b,Alpha{2},Beta,sol);
   sumup_traj = [sumup_traj sumup];
end
sumup_total(1) = mean(sumup_traj(1,2:end));
sumup_total(2) = mean(sumup_traj(2,2:end));
sumup_total
sum(sumup_total)

k = 1:1:Nstep;

% states
subplot(2,1,1)
stairs(k,x(1,2:end),'LineStyle','-','LineWidth',1);
hold on
stairs(k,x(2,2:end),'LineStyle','-','LineWidth',1);
stairs(k,x(3,2:end),'LineStyle','-','LineWidth',1);
stairs(k,x(4,2:end),'LineStyle','-','LineWidth',1);
xlabel('$[s]k$' ,'interpreter','latex')
ylabel('$x_k$','interpreter','latex');
h=legend( '$x_1$','$x_2$','Location', 'northeast');
set(h,'Interpreter','latex');
grid
% 
% control 
subplot(2,1,2)
stairs(k,u(1,1:end),'LineStyle','-','LineWidth',1);
xlabel('$k[s]$' ,'interpreter','latex')
ylabel('$u_k$','interpreter','latex');
h=legend( '$u_k$','Location', 'northeast');
set(h,'Interpreter','latex');
grid
% inter-events
% 
% figure(2)
% aux = 1;
% for i = 2:Nstep
%     if update(i)~= 0
%         stem(i-2, i-aux-1,'bo','MarkerFaceColor','auto');
%         aux = i;
%         hold on
%     end
% end
figure(2)
aux = zeros(2,1);
for k = 2:Nstep
    for i = 1:2
        if update(i,k)== 1
            subplot(2,1,i)
            stem(k-2, k-aux(i)-1,'b.','MarkerFaceColor','auto');
            aux(i) = k;
            hold on
        end
    end
end
% 
%ROA
x1 = linspace(-143,143,75);
x2 = linspace(-38,38,75);
x3 = linspace(-3,3,75);
x4 = linspace(-27,27,75);
a = 1;
for i = 1:75
    for j = 1:75
        for k = 1:75
            for z = 1:75
                V = [x1(i),x2(j),x3(k),x4(z)]*sol.P*[x1(i);x2(j);x3(k);x4(z)];
                if V <=1
                    pts(:,a) = [x1(i);x2(j);x3(k);x4(z)];
                    a = a+1;
                end
            end
        end
    end
end
figure(3)
subplot(1,2,1)
plot(pts(1,:),pts(2,:),'.','color','r' );
hold on
subplot(1,2,2)
plot(pts(3,:),pts(4,:),'.','color','r' );
hold on

P = cell(2,1);
P{1} = sol.P(1:2,1:2)-sol.P(1:2,3:4)*inv(sol.P(3:4,3:4))*sol.P(3:4,1:2);
P{2} = sol.P(3:4,3:4)-sol.P(3:4,1:2)*inv(sol.P(1:2,1:2))*sol.P(1:2,3:4);

lim = [44,13,1,9];
passo = 75;
[c,PTS] = GRID(sol.P,lim,passo);

ptsf = [];
for i=1:3:size(PTS,2)
    ptsf = [ptsf,PTS(:,i)];
end

%pts_total = [];
% for i=1:size(pts_lim,2)
%     for j=1:size(pts,2)
%         if pts_lim(:,i) == pts(3:4,j)
%            pts_total =  [pts_total, pts(:,j)];
%         end
%     end
% end


for i=1:2
    [U D V] = svd(P{i});
    
    z = 1/sqrt(D(1,1));
    y = 1/sqrt(D(2,2));
    theta = [0:1/20:2*pi+1/20];
    
    state(1,:) = z*cos(theta);
    state(2,:) = y*sin(theta);
    
    X = V * state;
    subplot(1,2,i)
    hold on
    plot(X(1,:),X(2,:),'Color','g','LineWidth',1,'LineStyle' ,'--');
    max(X(1,:))
    max(X(2,:))
end

x1 = linspace(-0.73,0.73,1e3);
for i=1:n(1)
    plot(x1,(deltav1-W{1}(i,1)*x1)/W{1}(i,2),'color','r') 
    plot(x1,(-deltav1-W{1}(i,1)*x1)/W{1}(i,2),'color','r')
    hold on;
end

