clear all
clc
%% parameters
g = 10; % gravitational coefficient
m = 0.15; % mass
l = 0.5; % length
mu = 0.05; % frictional coefficient
dt = 0.02; % sampling period

%% x^+ = AG*x + BG1*q + BG2*u
sysP.AG = [1,      dt;...
    g/l*dt, 1-mu/(m*l^2)*dt];
% describes how q enters the system
sysP.BG1 = [0;...
    -g/l*dt];
% describes how u enters the system
sysP.BG2 = [0;...
    dt/(m*l^2)];
sysP.nG = size(sysP.AG, 1);
nu = 1;
nq = 1;

%  v_Delta = CG*xG + [DG1 DG2]*[q; u] = xG
CG = [1, 0];
DG1 = 0;
DG2 = 0;

%% load weights and biases of the NN controller
% %fname = '../vehicle_training/Wb_s32_tanh/';
% fname = 'Wb_s32_tanh/';
% load([fname 'W1.csv'])
% load([fname 'W2.csv'])
% load([fname 'W3.csv'])
% W{1} = W1;
% W{2} = W2;
% W{3} = W3;

load('rev_5_sansCritic.mat')
% load('file_W3_ini.mat')
W{1} = W1;
W{2} = W2;
W{3} = W3;
W{4} = W4;
W{5} = W5;

%load('file_W3_ini.mat')

% for ii=0.2:0.1:0.4

nlayer = numel(W)-1;

b = cell(1,nlayer);
n = zeros(1,nlayer);
for i=1:nlayer+1
    n(i) = size(W{i},1);
    b{i} = zeros(n(i),1);
    sysC.W{i} = W{i};
    sysC.b{i} = b{i};
end
nphi = sum(n(1:nlayer));

Alpha = [];
xeq = [0.0; 0.0];
veq = cell(1,nlayer);
weq = cell(1,nlayer);
vup = cell(1,nlayer);
vlb = cell(1,nlayer);
wup = cell(1,nlayer);
wlb = cell(1,nlayer);
alpha = cell(1,nlayer);

veq{1} = W{1}*xeq + b{1};
weq{1} = tanh(veq{1});
for i = 2:nlayer
    veq{i} = W{i}*weq{i-1} + b{i};
    weq{i} = tanh(veq{i});
end

deltav1 = 0.04;
vup{1} = deltav1 + veq{1};
vlb{1} = veq{1} - deltav1;
%
beta = 1;
up = 0;
lb = 0;

alpha{1} = min((tanh(vup{1})-tanh(veq{1}))./(vup{1}-veq{1}), (tanh(veq{1})-tanh(vlb{1}))./(veq{1}-vlb{1}));
wup{1} = tanh(vup{1});
wlb{1} = tanh(vlb{1});
for i = 1:nlayer
    if i>1
        for j = 1:n(i)
            up = W{i}(j,:)*1/2*(wup{i-1}+wlb{i-1}) + b{i}(j) + abs(W{i}(j,:))*1/2*abs(wup{i-1}-wlb{i-1});
            lb = W{i}(j,:)*1/2*(wup{i-1}+wlb{i-1}) + b{i}(j) - abs(W{i}(j,:))*1/2*abs(wup{i-1}-wlb{i-1});
            vup{i} = [vup{i}; up];
            vlb{i} = [vlb{i}; lb];
        end
        alpha{i} = min((tanh(vup{i})-tanh(veq{i}))./(vup{i}-veq{i}), (tanh(veq{i})-tanh(vlb{i}))./(veq{i}-vlb{i}));
        wup{i} = tanh(vup{i});
        wlb{i} = tanh(vlb{i});
    end
    Alpha = blkdiag(Alpha,diag(alpha{i}));
end
Beta = beta*eye(nphi);

%% Define IQCs for the nonlinearity x1 - sin(x1)
% x1 - sin(x1) is slope-restricted in [0, 2] globally ---> off-by-one IQC

% x1 - sin(x1) is sector-bounded in [0, 1.22] globally ---> sector IQC
% x1 - sin(x1) is sector-bounded in [0, 1] locally on x1 in [-pi,pi]
% x1 - sin(x1) is sector-bounded in [0, 0.7606] locally on x1 in [-2.5,2.5]
% define the filter for off-by-one IQC
%L_slope = 2;
x1bound = 0.73;
L_slope = 1 - cos(x1bound);
m_slope = 0;
Apsi = 0;
sysP.nxi = size(Apsi,1);
Apsi = Apsi*dt + eye(sysP.nxi);
Bpsi1 = -L_slope;
Bpsi2 = 1;
Bpsi1 = Bpsi1*dt;
Bpsi2 = Bpsi2*dt;
Cpsi = [1; 0];
Dpsi1 = [L_slope; -m_slope];
Dpsi2 = [-1; 1];

%% construct the extended system
sysP.A = [sysP.AG, zeros(sysP.nG,sysP.nxi);...
    Bpsi1*CG, Apsi];
sysP.Bq = [sysP.BG1;
    Bpsi1*DG1+Bpsi2];
sysP.Bu = [sysP.BG2;
    Bpsi1*DG2];
sysP.C = [Dpsi1*CG, Cpsi];
sysP.Dq = Dpsi1*DG1+Dpsi2;
sysP.Du = Dpsi1*DG2;
sysP.nzeta = sysP.nG + sysP.nxi;

%% Convex Optimization - compute trigger parameters and ROA

% [sol,solPb] = code_NN_trigger_wq(sysP,sysC,Alpha{1},Beta,Alpha{2},1.05*Beta);

[sol,solPb] = code_NN_trigger_w_mod(sysP,sysC,Alpha,1.05049*eye(nphi),deltav1);
% % 
sol
% Revision
% 0.4 1.0549  27.33 21.75 24.54
% 0.15 1.0505 38.45 16.28 15.29 23.34
% 0.04 1.05049  48.65 48.33 48.33 48.26 48.39
% -------------------------------------
% 0.2 1.0009 / 0.3 1.2552 / 0.4 1.0505
%0.04 1.051 1e-08 
%0.15 1.05 1e-08

%% plot results
% Simulation results
Nstep = 500;
[vet val] = eig(sol.P(1:2,1:2));
x0 = 1/sqrt(val(1,1))*vet(:,1);
% x0 = 1/sqrt(val(2,2))*vet(:,2);
x0 = [0.3758 -1.485];
Nstep = 500;
sumup_traj = zeros(4,1);
sumup_total = zeros(4,1);
for i=1:100
   [x,u,update,sumup,erro] = NN_trigger_w_closedloop_3(Nstep,sysP,ptsf(:,i),W,b,Alpha,1.0505*Beta,sol);
   sumup_traj = [sumup_traj sumup];
end
sumup_total(1) = mean(sumup_traj(1,2:end));
sumup_total(2) = mean(sumup_traj(2,2:end));
sumup_total(3) = mean(sumup_traj(3,2:end));
sumup_total(4) = mean(sumup_traj(4,2:end));
sumup_total/5
sum(sumup_total)/20

% states
figure(1)

k = 1:1:Nstep;
subplot(2,1,1)
stairs(k,x(1,2:end),'LineStyle','-','LineWidth',1.2,'Color','b');
hold on
stairs(k,x(2,2:end),'LineStyle','-','LineWidth',1.2,'Color','g');
xlabel('$k$' ,'interpreter','latex')
ylabel('$x_k$','interpreter','latex');
h=legend( '$x_1$','$x_2$','Location', 'northeast');
set(h,'Interpreter','latex');
set(groot,'defaultAxesTickLabelInterpreter','latex'); 
grid

ax2 = axes('position',[.757 .816 .163 .145],'Box','on');
axes(ax2)
%hold on
%stairs(k(50:100),x(1,50:100),'LineStyle','-','LineWidth',1.2,'Color','b');%,'Marker','o', 'MarkerEdgeColor','auto', 'MarkerFaceColor','auto')
hold on
stairs(k(5:25),x(2,5:25),'LineStyle','-.','LineWidth',1,'Color','g');
%ylim([-1.4 -0.7])
grid

% control 
subplot(2,1,2)
stairs(k,u(1,1:end),'LineStyle','-','LineWidth',1.2,'Color','r');
hold on
xlabel('$k$' ,'interpreter','latex')
ylabel('$u_k$','interpreter','latex');
set(groot,'defaultAxesTickLabelInterpreter','latex'); 
grid

ax3 = axes('position',[.683 .272 .163 .145],'Box','on');
axes(ax3)
hold on
stairs(k(100:120),u(1,100:120),'LineStyle','-.','LineWidth',1.2,'Color','r');%,'Marker','o', 'MarkerEdgeColor','auto', 'MarkerFaceColor','auto')
%ylim([-1.4 -0.7])
grid

% inter-events
% 
% figure(2)
% subplot(2,1,1)
% aux = 1;
% for i = 2:Nstep
%     if update(i)~= 0
%         stem((i-2)*dt, i-aux-1,'b.','MarkerFaceColor','auto');
%         aux = i;
%         hold on
%     end
% end
% xlabel('$k$' ,'interpreter','latex')
% ylabel('Inter-events','interpreter','latex');
% grid

figure(2)
cor = {'m','c'};
fig = {'s','^'};
lin = {'-','-.'};
aux = zeros(2,1);
for k = 2:Nstep
    for i = 1:2
        if update(i,k)== 1
            subplot(2,1,1)
            stem(k-2, k-aux(i)-1,'LineStyle',lin{i},'Color',cor{i},'Marker',fig{i},'MarkerSize',3, 'MarkerFaceColor','auto');
            aux(i) = k;
            hold on
        end
    end
end

% plot(ScopeData1{1}.Values.Time, ScopeData1{1}.Values.Data,'Color','b','LineWidth',1)
% hold on
% plot(ScopeData1{2}.Values.Time, ScopeData1{2}.Values.Data,'Color','r','LineWidth',1)
% for i=1:size(trigger_instants.signals.values,1)
%     if trigger_instants.signals.values(i)==1
%         plot(ScopeData1{1}.Values.Time(i), ScopeData1{1}.Values.Data(i),'Marker','s','MarkerSize',3, 'MarkerEdgeColor','b', 'MarkerFaceColor','w');
%         hold on
%     end
% end

P = cell(2,1);
P{1} = sol.P(1:2,1:2)-sol.P(1:2,3)*inv(sol.P(3,3))*sol.P(3,1:2);
P{2} = sol.P(3,3)-sol.P(3,1:2)*inv(sol.P(1:2,1:2))*sol.P(1:2,3);

figure(3)
x1 = linspace(-0.1527,0.1527,100);
x2 = linspace(-0.7127,0.7127,100);
pts = [];
for i = 1:100
    for j = 1:100
        if [x1(i),x2(j)]*sol.P(1:2,1:2)*[x1(i);x2(j)] <=1
            plot(x1(i),x2(j),'.','color','b');
            hold on
            pts = [pts, [x1(i);x2(j)]];
        end
    end
end

ptsf = [];
for i=1:67:size(pts,2)
    ptsf = [ptsf,pts(:,i)];
end

for i=1:1
    [U D V] = svd(sol.P(1:2,1:2));
    
    z = 1/sqrt(D(1,1));
    y = 1/sqrt(D(2,2));
    theta = [0:1/20:2*pi+1/20];
    
    state(1,:) = z*cos(theta);
    state(2,:) = y*sin(theta);
    
    X = V * state;
    %subplot(1,2,i)
    hold on
    plot(X(1,:),X(2,:),'Color','m','LineWidth',1.2,'LineStyle' ,':');
    max(X(1,:))
    max(X(2,:))
end

lim = [0.12,0.9,3.0662e+03];
passo = 75;
[c,PTS] = GRID2(sol.P,lim,passo);

[~, D, ~] = svd(sol.P(1:2,1:2));
a = 1/sqrt(D(1,1));
b = 1/sqrt(D(2,2));
area = pi*a*b
c = 1/sqrt(D(3,3));
volume(1)= (4/3)*pi*a*b*c;
volume(2) = -log(det(sol.P(1:2,1:2)));
n = 2;
volume(3) = n^(n/2)*(pi^(n/2)/gamma(n/2+1))/sqrt(det(sol.P(1:2,1:2)));
volume(4) = trace(sol.P);
% 0.2132 -5.3804 0.4264
% 
x1 = linspace(-0.50,0.50,3);
for i=1:n(1)
    plot(x1,(deltav1(1)-W{1}(i,1)*x1)/W{1}(i,2),'color', [0.8392    0.8157    0.7843]) 
    plot(x1,(-deltav1(1)-W{1}(i,1)*x1)/W{1}(i,2),'color',[0.8392    0.8157    0.7843])
    hold on;
end
xlabel('$x_1$','interpreter','latex')
ylabel('$x_2$','interpreter','latex');
grid

%--------------------------------------------------------------

%%r21 = [99.32 99.05 98.85 38.41 38.37 38.08 22.24 21.96 21.99];
r22 = [99.25 98.91 98.56 38.37 38.39 37.77 22.14 21.92 21.88];

plot(alpha,r21(1:3),'bo-','LineWidth',1)
hold on
plot(alpha,r21(4:6),'bs--','LineWidth',1)
hold on
plot(alpha,r21(7:9),'b^-.','LineWidth',1)
hold on

plot(alpha,r22(1:3),'o-','LineWidth',1)
hold on
plot(alpha,r22(4:6),'s--','LineWidth',1)
hold on
plot(alpha,r22(7:9),'^-.','LineWidth',1)
hold on

%%
Beta1=1.05*eye(nphi);
Beta2 = 1.02*eye(nphi);
eig([eye(nphi),Beta2]*([sol.X sol.Y;sol.Y' sol.Z]-[2*Beta1*sol.T*(Beta1-Alpha) -(Beta1-Alpha)*sol.T;
          -sol.T*(Beta1-Alpha) zeros(nphi)]+[-2*Beta1*sol.T*Alpha  (Beta1+Alpha)*sol.T ;
           sol.T*(Beta1+Alpha) -2*sol.T])*[eye(nphi);Beta2])
       
eig([eye(nphi),Beta2]*([2*Beta1*sol.T*(Beta1-Alpha) -(Beta1-Alpha)*sol.T;
          -sol.T*(Beta1-Alpha) zeros(nphi)]-[-2*Beta1*sol.T*Alpha  (Beta1+Alpha)*sol.T ;
           sol.T*(Beta1+Alpha) -2*sol.T])*[eye(nphi);Beta2])
 
eig([eye(nphi),Beta2]*([2*Beta1*sol.T*(Beta1-Alpha) -(Beta1-Alpha)*sol.T;
          -sol.T*(Beta1-Alpha) zeros(nphi)])*[eye(nphi);Beta2])

eig([eye(nphi),Beta2]*([-2*Beta1*sol.T*Alpha  (Beta1+Alpha)*sol.T ;
           sol.T*(Beta1+Alpha) -2*sol.T])*[eye(nphi);Beta2])
         
 eig([eye(nphi),Beta2]*([sol.X sol.Y;sol.Y' sol.Z])*[eye(nphi);Beta2])