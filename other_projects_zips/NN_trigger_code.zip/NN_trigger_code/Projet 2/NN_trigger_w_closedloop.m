function [x,u,update,sumup,erro] = NN_trigger_w_closedloop(Nstep,sysP,x0,W,b,Alpha,Beta,sol)

AG = sysP.AG;
BG = sysP.BG2;
Bq = sysP.BG1;

nlayer = numel(W)-1;
n = zeros(1,nlayer);
for i=1:nlayer
    n(i) = size(W{i},1);
end

Nx = numel(x0);

x = zeros(Nx,Nstep);
x(:,2) = x0;

w = cell(nlayer+1,1);
w{1,1} =  zeros(Nx,1);
wh{1,1} = zeros(Nx,1);
v{1,1} =  zeros(Nx,1);
erro = zeros(nlayer,Nstep);
erro_next = cell(1,nlayer);
for i = 2:nlayer+1
    w{i,1} = zeros(n(i-1),1);
    wh{i,1} = zeros(n(i-1),1);
    v{i,1} = zeros(n(i-1),1);
    erro_next{i} = zeros(1,i-1);
end    

Nu = size(W{end},1);
u = zeros(Nu,Nstep);

update = zeros(nlayer,Nstep);
sumup = zeros(nlayer,1);

theta = zeros(nlayer,Nstep);

alpha = cell(nlayer,1);
beta = cell(nlayer,1);
Tn = cell(nlayer,1);
for i=1:nlayer
    alpha{i} = Alpha(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
    beta{i} = Beta(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
    Tn{i} = sol.T(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
end

% Simulate System
for k = 2:Nstep
    
    wopt = cell(1,nlayer+1);
    wh{1,k} = x(:,k);
    v{2,k} = W{1}*wh{1,k} + b{1};
    w{2,k} = tanh(v{2,k});
    erro_next{2} = [v{2,k}' wh{2,k-1}']*[-2*alpha{1}*beta{1}*Tn{1}  (alpha{1}+beta{1})*Tn{1};
                                (alpha{1}+beta{1})*Tn{1} -2*eye(n(1))*Tn{1}]*[v{2,k}; wh{2,k-1}];
    wopt{2} = [w{2,k},wh{2,k-1}];
    for i = 3:nlayer+1
        for j = 1:2
            v{i,k} = W{i-1}*wopt{i-1}(:,j) + b{i-1};
            w{i,k} = tanh(v{i,k});
            erro_next{i}(:,j) = [v{i,k}' wh{i,k-1}']*[-2*alpha{i-1}*beta{i-1}*Tn{i-1}  (alpha{i-1}+beta{i-1})*Tn{i-1};
                                (alpha{i-1}+beta{i-1})*Tn{i-1} -2*eye(n(i-1))*Tn{i-1}]*[v{i,k}; wh{i,k-1}];
            wopt{i} = [wopt{i},w{i,k}];
        end
    end
    
    delta  = [];
    for i = 2:nlayer
        for j= i+1:nlayer+1
            aux = [];
            for s = 1:size(erro_next{j},2)
                aux = [aux, erro_next{i}-erro_next{j}(:,s)];
            end
            delta = [delta,max(aux)];
        end
    end
     theta(:,k) = inv([1 1;1 -1])*[0;delta(1)];
%    theta(:,k) = inv([1 1 1;1 -1 0;1 0 -1])*[0;delta(1);delta(2)];
    
    wh{1,k} = x(:,k);  
    
    for i = 1:nlayer
        
        v{i+1,k} = W{i}*wh{i,k} + b{i};
        w{i+1,k} = tanh(v{i+1,k});
        
        erro(i,k) = [v{i+1,k}' wh{i+1,k-1}']*[-2*alpha{i}*beta{i}*Tn{i}  (alpha{i}+beta{i})*Tn{i};
        (alpha{i}+beta{i})*Tn{i} -2*eye(n(i))*Tn{i}]*[v{i+1,k}; wh{i+1,k-1}];
        
        if erro(i,k) >= theta(i,k);
            wh{i+1,k} = wh{i+1,k-1};
            update(i,k) = 0;
        else
            wh{i+1,k} = w{i+1,k};
            update(i,k) = 1;
            sumup(i) = sumup(i) + 1;            
        end
    end
    u(:,k) = W{end}*wh{end,k}+b{end};
    
%     x(:,k+1) = x(:,k)+[x(2,k);...
%         g/l*sin(x(1,k))-mu/(m*l^2)*x(2,k)+1/(m*l^2)*u(:,k)]*dt;
%     x(:,k+1) = sysP.A*x(:,k)+sysP.B*u(:,k)+sysP.B2*(x(1,k)-sin(x(1,k)));
    x(:,k+1) = AG*x(:,k)+BG*u(:,k)+Bq*(x(1,k)-sin(x(1,k)));
    
%     if k<=500
%        plot(v{2,k}(3),wh{2,k-1}(3),'r.')
%        hold on
%        plot(v{2,k}(3),wh{2,k}(3),'bs')
%     end
%    
% end
% xx = linspace(-0.1,0.1,100);
% yy = alpha{2}(3,3)*xx;
% zz = tanh(xx);
% plot(xx,yy,'g-')
% hold on
% plot(zz,yy,'b-')
% line([-0.1 0.1],[-0.1 0.1],'Color','g');
end
