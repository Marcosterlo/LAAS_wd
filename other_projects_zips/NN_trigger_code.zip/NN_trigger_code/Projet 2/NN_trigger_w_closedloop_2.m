function [x,u,update,sumup,erro] = NN_trigger_w_closedloop_2(Nstep,sysP,x0,W,b,Alpha,Beta,sol)

AG = sysP.AG;
BG = sysP.BG2;
Bq = sysP.BG1;

nlayer = numel(W)-1;
n = zeros(1,nlayer);
for i=1:nlayer
    n(i) = size(W{i},1);
end

Nx = numel(x0);

x = zeros(Nx,Nstep);
x(:,2) = x0;

w = cell(nlayer+1,1);
w{1,1} =  zeros(Nx,1);
wh{1,1} = x0;
v{1,1} =  zeros(Nx,1);
erro = zeros(nlayer,Nstep);
for i = 2:nlayer+1
    w{i,1} = zeros(n(i-1),1);
    wh{i,1} = zeros(n(i-1),1);
    v{i,1} = zeros(n(i-1),1);
end    

Nu = size(W{end},1);
u = zeros(Nu,Nstep);

update = zeros(nlayer,Nstep);
sumup = zeros(nlayer,1);

alpha = cell(nlayer,1);
beta = cell(nlayer,1);
Tn = cell(nlayer,1);
Pi = cell(nlayer,1);
for i=1:nlayer
    alpha{i} = Alpha(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
    beta{i} = Beta(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
    Tn{i} = sol.T(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
    Pi{i} = [sol.X(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i))), sol.Y(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
        sol.Y(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i))), sol.Z(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)))];
end
% Simulate System
for k = 2:Nstep
    
    flag = 0;
    
    cont = 0;
    
   [theta] = calcula_theta(n, nlayer, x(:,k), {wh{2,k-1},wh{3,k-1}}, W, b, alpha, beta, Tn, Pi);%
    %                                            %,wh{4,k-1},wh{5,k-1}
    wh{1,k} = x(:,k);                      
    
    while flag == 0
    
    for i = 1:nlayer
        
        v{i+1,k} = W{i}*wh{i,k} + b{i};
        w{i+1,k} = tanh(v{i+1,k});
        
        M = [-2*alpha{i}*beta{i}*Tn{i}  (alpha{i}+beta{i})*Tn{i};
        (alpha{i}+beta{i})*Tn{i} -2*eye(n(i))*Tn{i}]+Pi{i}-[2*beta{i}*(beta{i}-alpha{i})*Tn{i}  -(beta{i}-alpha{i})*Tn{i};
        -(beta{i}-alpha{i})*Tn{i} zeros(n(i))];%;
        
        erro(i,k) = [v{i+1,k}' wh{i+1,k-1}']*M*[v{i+1,k}; wh{i+1,k-1}];
        
        if erro(i,k) >=theta(i)
            wh{i+1,k} = wh{i+1,k-1};
            update(i,k) = 0;
        else
            wh{i+1,k} = w{i+1,k};
            update(i,k) = 1;           
        end
    end
%     
    if cont == 0
       [theta_new] = avalia_theta2(n, nlayer, theta, {v{2,k},v{3,k}},{wh{2,k},wh{3,k}}, alpha, beta, Tn, Pi);  
    end                                                      %,v{4,k},v{5,k},wh{4,k},wh{5,k}
    if theta_new == theta
        flag = 1;
    else
        theta = theta_new;
        cont = 1;
    end
    end
    th(:,k) = theta;
    u(:,k) = W{end}*wh{end,k}+b{end};
    
%     x(:,k+1) = x(:,k)+[x(2,k);...
%         g/l*sin(x(1,k))-mu/(m*l^2)*x(2,k)+1/(m*l^2)*u(:,k)]*dt;
%     x(:,k+1) = sysP.A*x(:,k)+sysP.B*u(:,k)+sysP.B2*(x(1,k)-sin(x(1,k)));
    x(:,k+1) = AG*x(:,k)+BG*u(:,k)+Bq*(x(1,k)-sin(x(1,k)));
    
%     if k<=500
%        plot(v{2,k}(3),wh{2,k-1}(3),'r.')
%        hold on
%        plot(v{2,k}(3),wh{2,k}(3),'bs')
%     end
%    
% end
% xx = linspace(-0.1,0.1,100);
% yy = alpha{2}(3,3)*xx;
% zz = tanh(xx);
% plot(xx,yy,'g-')
% hold on
% plot(zz,yy,'b-')
% line([-0.1 0.1],[-0.1 0.1],'Color','g');
end
for i=1:nlayer
    sumup(i) = sum(update(i,:)); 
end
end