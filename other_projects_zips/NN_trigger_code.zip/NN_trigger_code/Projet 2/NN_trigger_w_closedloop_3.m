function [x,u,update,sumup,erro] = NN_trigger_w_closedloop_3(Nstep,sysP,x0,W,b,Alpha,Beta,sol)

AG = sysP.AG;
BG = sysP.BG2;
Bq = sysP.BG1;

nlayer = numel(W)-1;
n = zeros(1,nlayer);
for i=1:nlayer
    n(i) = size(W{i},1);
end

Nx = numel(x0);

x = zeros(Nx,Nstep);
x(:,2) = x0;

w = cell(nlayer+1,1);
w{1,1} =  zeros(Nx,1);
wh{1,1} = x0;
v{1,1} =  zeros(Nx,1);
erro = zeros(nlayer,Nstep);
for i = 2:nlayer+1
    w{i,1} = zeros(n(i-1),1);
    wh{i,1} = zeros(n(i-1),1);
    v{i,1} = zeros(n(i-1),1);
end    

Nu = size(W{end},1);
u = zeros(Nu,Nstep);

update = zeros(nlayer,Nstep);
sumup = zeros(nlayer,1);

alpha = cell(nlayer,1);
beta = cell(nlayer,1);
Tn = cell(nlayer,1);
Pi = cell(nlayer,1);
for i=1:nlayer
    alpha{i} = Alpha(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
    beta{i} = Beta(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
    Tn{i} = sol.T(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
     Pi{i} = [sol.X(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i))), sol.Y(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)));
         sol.Y(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i))), sol.Z(1+sum(n(1:i-1)):sum(n(1:i)),1+sum(n(1:i-1)):sum(n(1:i)))];
end

for k = 2:Nstep
                                               
    wh{1,k} = x(:,k);                      

    for i = 1:nlayer
        
        v{i+1,k} = W{i}*wh{i,k} + b{i};
        
        w{i+1,k} = tanh(v{i+1,k});
        
        M = Pi{i};% [-2*alpha{i}*beta{i}*Tn{i}  (alpha{i}+beta{i})*Tn{i};
%         (alpha{i}+beta{i})*Tn{i} -2*eye(n(i))*Tn{i}]-[2*beta{i}*(beta{i}-alpha{i})*Tn{i}  -(beta{i}-alpha{i})*Tn{i};
%        -(beta{i}-alpha{i})*Tn{i} zeros(n(i))]+Pi{i};
%         
        erro(i,k) = [v{i+1,k}' wh{i+1,k-1}']*M*[v{i+1,k}; wh{i+1,k-1}];
        
        if erro(i,k) >=0
            wh{i+1,k} = wh{i+1,k-1};
            update(i,k) = 0;
        else
            wh{i+1,k} = w{i+1,k};
            update(i,k) = 1;           
        end
    end
%     
    u(:,k) = W{end}*wh{end,k}+b{end};
    
    x(:,k+1) = AG*x(:,k)+BG*u(:,k)+Bq*(x(1,k)-sin(x(1,k)));

end
for i=1:nlayer
    sumup(i) = sum(update(i,:)); 
end
end