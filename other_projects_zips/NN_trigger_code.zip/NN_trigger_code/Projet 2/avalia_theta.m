function [theta] = avalia_theta(n, nlayer, theta, x, W, b, alpha, beta, Tn)

erro = zeros(1,nlayer);
v = cell(nlayer,1);
w = cell(nlayer,1);
for i = 1:nlayer
    w{i} = zeros(n(i),1);
    v{i} = zeros(n(i),1);
end

v{1} = W{1}*x + b{1};
w{1} = tanh(v{1});

erro(1) = [v{1}' w{1}']*[-2*alpha{1}*beta{1}*Tn{1}  (alpha{1}+beta{1})*Tn{1};
    (alpha{1}+beta{1})*Tn{1} -2*eye(n(1))*Tn{1}]*[v{1}; w{1}];

for i=2:nlayer
    
    v{i} = W{i}*w{i-1} + b{i};
    w{i} = tanh(v{i});
    
    erro(i) = [v{i}' w{i}']*[-2*alpha{i}*beta{i}*Tn{i}  (alpha{i}+beta{i})*Tn{i};
        (alpha{i}+beta{i})*Tn{i} -2*eye(n(i))*Tn{i}]*[v{i}; w{i}];
end
pos = [];
erro_pos = [];
for i=1:nlayer
    if theta(i)> 0 
        pos = [pos, theta(i)];
        erro_pos = [erro_pos, erro(i)];
    end 
end
for i=1:size(pos,2)
    if erro_pos(i)< theta(i)
        theta = zeros(1,nlayer);
        break;
    end
end
end