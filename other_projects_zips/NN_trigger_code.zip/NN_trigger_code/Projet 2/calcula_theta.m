function [theta] = calcula_theta(n, nlayer, x, wh, W, b, alpha, beta, Tn,Pi)

nG = size(x,1);
w = cell(nlayer,1);
v = cell(nlayer,1);
erro_next = cell(1,nlayer);
for i = 1:nlayer
    w{i} = zeros(n(i),1);
    v{i} = zeros(n(i),1);
    erro_next{i} = zeros(1,i);
end

wopt = cell(1,nlayer);
v{1} = W{1}*x + b{1};
w{1} = tanh(v{1});
M1 = [-2*alpha{1}*beta{1}*Tn{1}  (alpha{1}+beta{1})*Tn{1};
        (alpha{1}+beta{1})*Tn{1} -2*eye(n(1))*Tn{i}]+ Pi{1}-[2*beta{1}*(beta{1}-alpha{1})*Tn{1}  -(beta{1}-alpha{1})*Tn{1};
       -(beta{1}-alpha{1})*Tn{1} zeros(n(1))];%
        
erro_next{1} = [v{1}' wh{1}']*M1*[v{1}; wh{1}];
wopt{1} = [w{1},wh{1}];
for i = 2:nlayer
    for j = 1:2
        v{i} = W{i}*wopt{i-1}(:,j) + b{i};
        w{i} = tanh(v{i});
        M = [-2*alpha{i}*beta{i}*Tn{i}  (alpha{i}+beta{i})*Tn{i};
        (alpha{i}+beta{i})*Tn{i} -2*eye(n(i))*Tn{i}]+ Pi{i}-[2*beta{i}*(beta{i}-alpha{i})*Tn{i}  -(beta{i}-alpha{i})*Tn{i};
       -(beta{i}-alpha{i})*Tn{i} zeros(n(i))];%
        
        erro_next{i}(:,j) = [v{i}' wh{i}']*M*[v{i}; wh{i}];
        wopt{i} = [wopt{i},w{i}];
    end
end

delta  = [];
for i= 2:nlayer
    aux = [];
    for j = 1:size(erro_next{i},2)
        aux = [aux, erro_next{1}-erro_next{i}(:,j)];
    end
    delta = [delta,max(aux)];
end

%theta = inv([1 1;1 -1])*[0;delta(1)];
theta = inv([1 1 1;1 -1 0;1 0 -1])*[0;delta(1);delta(2)];
%theta = inv([1 1 1 1;1 -1 0 0;1 0 -1 0;1 0 0 -1])*[0;delta(1);delta(2);delta(3)];
end