function [sol,solPb] = code_NN_trigger_w_mod(sysP,sysC,alpha,beta,deltav1)

pbLMI = [];
Acl = sysP.A;
Bcl = sysP.Bu;
Bq = sysP.Bq;
Ccl = sysP.C;
Dcl = sysP.Du;
Dq = sysP.Dq;

nG = sysP.nG;
nxi = sysP.nxi;
nzeta = sysP.nzeta;
nu = 1;
nq = 1;
nlayer = numel(sysC.W)-1;

N = [];
n = zeros(1,nlayer);
W = cell(1,nlayer);
for i=1:nlayer+1
    W{i} = sysC.W{i};
    n(i) = size(W{i},1);
    N = blkdiag(N,W{i});
end
nphi = sum(n(1:nlayer));
Nux = N(nphi+1:end,1:nG);
Nuw = N(nphi+1:end,nG+1:end);
Nvx = N(1:nphi,1:nG);
Nvw = N(1:nphi,nG+1:end);
Nuzeta = [Nux, zeros(nu,nxi)];
Nvzeta = [Nvx, zeros(nphi,nxi)];

% M matrix for off-by-one IQC 
M_off = [0, 1;
         1, 0];
% define the filter for sector IQC
%L_sector = 0.7606;
x1bound = 0.73;
L_sector = (x1bound - sin(x1bound))/x1bound;
m_sector = 0;
Psi_sec = [L_sector, -1;...
           -m_sector,    1];
% M matrix for sector IQC
M_sec = [0, 1;...
         1, 0];

%%
% Definition des variableset du systeme de LMIs a contruire
a = sdpvar(1,1);   
pbLMI = pbLMI + (a>=0);
P = sdpvar(nzeta,nzeta,'symmetric');   
pbLMI = pbLMI + (P>=1e-8*eye(size(P)));%
T = sdpvar(nphi,nphi,'diagonal');
pbLMI = pbLMI + (T>=0);
lambda1 = sdpvar(1,1);
pbLMI = pbLMI + (lambda1>=0);
lambda2 = sdpvar(1,1);
pbLMI = pbLMI + (lambda2>=0);
X = sdpvar(nphi,nphi,'diagonal');
Y = sdpvar(nphi,nphi,'diagonal');
Z = sdpvar(nphi,nphi,'diagonal');
pbLMI = pbLMI + (Z<=0);% + (X>=-0.21*eye(nphi)) +(X<=0.03*eye(nphi));

Rphis = [Nvzeta Nvw zeros(nphi,nq);
        zeros(nphi,nzeta) eye(nphi) zeros(nphi,nq)];   
    
Mphi_1 = [X Y;Y' Z];    
% 
% Mphi_2 =  [2*beta*T*(beta-alpha) -(beta-alpha)*T;
%           -T*(beta-alpha)       zeros(nphi)];
%       
% Mphi_3 = [-2*beta*T*alpha  (beta+alpha)*T ;
%            T*(beta+alpha) -2*T];  
         
Qphis = Rphis'*(Mphi_1)*Rphis;%-Mphi_2+Mphi_3

Rs = [eye(nzeta) zeros(nzeta,nphi) zeros(nzeta,nq);
      Nuzeta Nuw zeros(nu,nq);
      zeros(nq,nzeta) zeros(nq,nphi) eye(nq)];

lmi11 = Acl'*P*Acl-P;
lmi12 = Acl'*P*Bcl;
lmi13 = Acl'*P*Bq;
lmi22 = Bcl'*P*Bcl;
lmi23 = Bcl'*P*Bq;
lmi33 = Bq'*P*Bq;

Qs = [lmi11  lmi12 lmi13;
      lmi12' lmi22 lmi23;
      lmi13' lmi23' lmi33];

Qlyap = Rs'*Qs*Rs;
  
Qoff = lambda2*Rs'*[Ccl Dcl Dq]'...
    *M_off*[Ccl Dcl Dq]*Rs;     

R_sec = [eye(1,1),zeros(1,1+nxi+nphi+nq);...
       zeros(nq,nzeta+nphi),eye(nq)];
   
Qsec = lambda1*R_sec'*Psi_sec'*M_sec*Psi_sec*R_sec;   

MSTAB =  Qlyap  + Qphis + Qoff + Qsec; 

pbLMI = pbLMI + (MSTAB <= 0) + (MSTAB>=-a*eye(nzeta+nphi+nq));

lmi111 = deltav1^2;
lmi122 = P;
for i = 1:n(1)
    lmi112 = [W{1}(i,:) zeros(1,nxi)];
    MSETOR = [lmi111 lmi112;
    lmi112' lmi122];
    pbLMI = pbLMI + (MSETOR>=0);
end

x1bound = 0.73;
lmi211 = x1bound^2;
lmi212 = [1,0, zeros(1,nxi)];
lmi222 = P;
MSETOR2 = [lmi211 lmi212;
    lmi212' lmi222];
pbLMI = pbLMI + (MSETOR2>=0);

pbLMI = pbLMI +([eye(nphi),beta]*(Mphi_1)*[eye(nphi);beta]>=0);%-Mphi_2+Mphi_3

pbLMI = pbLMI +([eye(nphi),alpha]*(Mphi_1)*[eye(nphi);alpha]>=0);%-Mphi_2+Mphi_3

% critere d'optimisation
critOPTIM = a;%trace(P(1:2,1:2));%trace(Qw(1:n1,1:n1));%(n1+1:n1+n2,n1+1:n1+n2)
% les options d'optimisation);%trace(Qw);%%%%
% les options d'optimisation
% --------------------------
options_sdp = sdpsettings('verbose',0,'warning',0,'solver','sdpt3');
options_sdp.sdpt3.maxit    = 200;
options_sdp.lmilab.maxiter = 500;    % default = 100
options_sdp.lmilab.reltol = 0.001;    % default = 0.01?? in lmilab 1e-03
options_sdp.lmilab.feasradius = 1e9; % R<0 signifie "no bound", default = 1e9

% resolution du probleme
solPb = solvesdp(pbLMI,critOPTIM,options_sdp);
%solPb = optimize(pbLMI,critOPTIM,options_sdp);

feasible = min(checkset(pbLMI))
if (feasible >= 0) % && solPb.problem == 0)
    sol.P = double(P);
    sol.T = double(T);
    sol.X = double(X);
    sol.Y = double(Y);
    sol.Z = double(Z);
else
    sol.P = [];
    sol.T = [];
end

end