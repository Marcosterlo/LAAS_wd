clear all
clc
%% Exemplo 1
g = 10; % gravitational coefficient
m = 0.15; % mass
l = 0.5; % length
mu = 0.05; % frictional coefficient
dt = 0.02; % sampling period

% x^+ = AG*x + BG1*q + BG2*u
AG = [1,      dt;...
    g/l*dt, 1-mu/(m*l^2)*dt];
% describes how u enters the system
BG = [0;...
    dt/(m*l^2)];
% 
% sysP.AG = AG;
% sysP.BG = BG;

%% Exemplo 2
% 
% AG = [0.935 0.019;-0.907 0.913];
% 
% BG = [-0.006;-1.120];

% AG = [0.7326 -0.0861;0.1722 0.9902];
%
% BG = [0.0609;0.0064];

sysP.AG = AG;
sysP.BG = BG;

%% load weights and biases of the NN controller
% %fname = '../vehicle_training/Wb_s32_tanh/';
fname = 'Wb_s32_relu/';
load([fname 'W1.csv'])
load([fname 'W2.csv'])
load([fname 'W3.csv'])

%load('Relu_2_YSA21.mat')
%load('GTM_relu_ini_1.mat')
%load('file_W3_ini.mat')
W{1} = W1;
W{2} = W2;
W{3} = W3;
% b{1} = b1;
% b{2} = b2;
% b{3} = b3;

nlayer = numel(W)-1;
b = cell(1,nlayer);
n = zeros(1,nlayer);
for i=1:nlayer+1
    n(i) = size(W{i},1);
    b{i} = zeros(n(i),1);
    sysC.W{i} = W{i};
    sysC.b{i} = b{i};
end
nphi = sum(n(1:nlayer));

%% Convex Optimization - compute trigger parameters and ROA

% [sol,solPb] = code_NN_trigger_wq(sysP,sysC,Alpha{1},Beta,Alpha{2},1.05*Beta);

%[sol,solPb] = code_NN_trigger_w(sysP,sysC,Alpha,1.05*Beta,deltav1);

% Alpha = blkdiag(diag(0.9*ones(1,nphi/2)),0.9*diag(ones(1,nphi/2)));
% [sol,solPb] = code_NN_trigger_w_2(sysP,sysC,Alpha,1.00*Beta);
Alpha = -0.42*eye(nphi);
Beta = 0*eye(nphi);

[sol,solPb] = code_NN_trigger_w_2(sysP,sysC,Alpha,Beta);

for t2 =1e-06:1e-03:1e-02
epsilon =  5;%2.4e-01;%2.40e-01;4.1667
t1 = 1.6e-04;%2.5e-03;% 1.5e-03;1.5e-04
t2 = 1.6e-03;%1.8e-02;% 1.0e-02;1.8e-02
t2<=1+t1
t2>=t1*epsilon
[sol,solPb] = code_NN_trigger_wv(sysP,sysC,Alpha,Beta,t1,t2,epsilon);
end

%critOPTIM = code_NN_trigger_w_fmin(t1);
epsilon = 4.1667;
critOPTIM = code_NN_trigger_w_fmin2(epsilon);
options = optimset('Display','iter','PlotFcns',@optimplotfval);
[epsilon,fval,exitflag,output] = fminsearch(@code_NN_trigger_w_fmin2,epsilon,options)

%% plot results
% Simulation results
Nstep = 500;
[vet val] = eig(sol.P(1:2,1:2));
x0 = 1/sqrt(val(1,1))*vet(:,1);
% x0 = 1/sqrt(val(2,2))*vet(:,2);
x0 = 10000*[0.3758 -1.485];
Nstep = 1000;
sumup_traj = zeros(2,1);
sumup_total = zeros(2,1);
%for i=1:100
for i=-6:0.3:6
    for j=-6:0.3:6
        x0 = [i,j];
       [x,u] = NN_trigger_w_closedloop_2(Nstep,sysP,x0,W,b,Alpha,Beta);
        if abs(x(1,end))>1
            plot(x(1,2:end),x(2,2:end),'g-.','LineWidth',1)
            hold on
            plot(x(1,2),x(2,2),'g*')
        else
            plot(x(1,2:end),x(2,2:end),'c-','LineWidth',1)
            hold on
            plot(x(1,2),x(2,2),'cs')
        end
        %    sumup_traj = [sumup_traj sumup];
    end
end
xlim([-6 6])
ylim([-6 6])
% sumup_total(1) = mean(sumup_traj(1,2:end));
% sumup_total(2) = mean(sumup_traj(2,2:end));
% sumup_total/500
% sum(sumup_total)/1000

% states
figure(1)

k = 1:1:Nstep;
subplot(2,1,1)
stairs(k,x(1,2:end),'LineStyle','-.','LineWidth',1.2,'Color','b');
hold on
stairs(k,x(2,2:end),'LineStyle','-.','LineWidth',1.2,'Color','g');
xlabel('$[s]k$' ,'interpreter','latex')
ylabel('$x_k$','interpreter','latex');
h=legend( '$x_1$','$x_2$','Location', 'northeast');
set(h,'Interpreter','latex');
grid

ax2 = axes('position',[.757 .816 .163 .145],'Box','on');
axes(ax2)
%hold on
%stairs(k(50:100),x(1,50:100),'LineStyle','-','LineWidth',1.2,'Color','b');%,'Marker','o', 'MarkerEdgeColor','auto', 'MarkerFaceColor','auto')
hold on
stairs(k(5:25),x(2,5:25),'LineStyle','-.','LineWidth',1,'Color','g');
%ylim([-1.4 -0.7])
grid

% control 
subplot(2,1,2)
stairs(k,u(1,1:end),'LineStyle','-.','LineWidth',1.2,'Color','r');
hold on
xlabel('$k[s]$' ,'interpreter','latex')
ylabel('$u_k$','interpreter','latex');
% h=legend( '$u_k$','Location', 'northeast');
% set(h,'Interpreter','latex');
grid

ax3 = axes('position',[.683 .272 .163 .145],'Box','on');
axes(ax3)
hold on
stairs(k(100:120),u(1,100:120),'LineStyle','-.','LineWidth',1.2,'Color','r');%,'Marker','o', 'MarkerEdgeColor','auto', 'MarkerFaceColor','auto')
%ylim([-1.4 -0.7])
grid

% inter-events
% 
% figure(2)
% subplot(2,1,1)
% aux = 1;
% for i = 2:Nstep
%     if update(i)~= 0
%         stem((i-2)*dt, i-aux-1,'b.','MarkerFaceColor','auto');
%         aux = i;
%         hold on
%     end
% end
% xlabel('$k$' ,'interpreter','latex')
% ylabel('Inter-events','interpreter','latex');
% grid

figure(2)
aux = zeros(2,1);
for k = 2:Nstep
    for i = 1:2
        if update(i,k)== 1
            subplot(2,1,i)
            stem(k-2, k-aux(i)-1,'LineStyle','-.','Color','c','Marker','^','MarkerSize',3, 'MarkerFaceColor','auto');
            aux(i) = k;
            hold on
        end
    end
end

% plot(ScopeData1{1}.Values.Time, ScopeData1{1}.Values.Data,'Color','b','LineWidth',1)
% hold on
% plot(ScopeData1{2}.Values.Time, ScopeData1{2}.Values.Data,'Color','r','LineWidth',1)
% for i=1:size(trigger_instants.signals.values,1)
%     if trigger_instants.signals.values(i)==1
%         plot(ScopeData1{1}.Values.Time(i), ScopeData1{1}.Values.Data(i),'Marker','s','MarkerSize',3, 'MarkerEdgeColor','b', 'MarkerFaceColor','w');
%         hold on
%     end
% end

P = cell(2,1);
P{1} = sol.P(1:2,1:2)-sol.P(1:2,3)*inv(sol.P(3,3))*sol.P(3,1:2);
P{2} = sol.P(3,3)-sol.P(3,1:2)*inv(sol.P(1:2,1:2))*sol.P(1:2,3);

figure(3)
x1 = linspace(-1,1,100);
x2 = linspace(-2,2,100);
pts = [];
for i = 1:100
    for j = 1:100
        if [x1(i),x2(j)]*sol.P(1:2,1:2)*[x1(i);x2(j)] <=9
            plot(x1(i),x2(j),'.','color','r');
            hold on
            pts = [pts, [x1(i);x2(j)]];
        end
    end
end

ptsf = [];
for i=1:62:size(pts,2)
    ptsf = [ptsf,pts(:,i)];
end

for i=1:1
    [U D V] = svd(sol.P(1:2,1:2));
    
    z = 1/sqrt(D(1,1));
    y = 1/sqrt(D(2,2));
    theta = [0:1/20:2*pi+1/20];
    
    state(1,:) = z*cos(theta);
    state(2,:) = y*sin(theta);
    
    X = V * state;
    %subplot(1,2,i)
    hold on
    plot(X(1,:),X(2,:),'Color','r','LineWidth',1.2,'LineStyle' ,'-');
    max(X(1,:))
    max(X(2,:))
end

lim = [0.12,0.9,3.0662e+03];
passo = 75;
[c,PTS] = GRID2(sol.P,lim,passo);

[~, D, ~] = svd(sol.P(1:2,1:2));
a = 1/sqrt(D(1,1));
b = 1/sqrt(D(2,2));
area = pi*a*b
c = 1/sqrt(D(3,3));
volume(1)= (4/3)*pi*a*b*c;
volume(2) = -log(det(sol.P(1:2,1:2)));
n = 2;
volume(3) = n^(n/2)*(pi^(n/2)/gamma(n/2+1))/sqrt(det(sol.P(1:2,1:2)));
volume(4) = trace(sol.P);
% 0.2132 -5.3804 0.4264
% 
x1 = linspace(-0.50,0.50,3);
for i=1:n(1)
    plot(x1,(deltav1(1)-W{1}(i,1)*x1)/W{1}(i,2),'color', [0.8392    0.8157    0.7843]) 
    plot(x1,(-deltav1(1)-W{1}(i,1)*x1)/W{1}(i,2),'color',[0.8392    0.8157    0.7843])
    hold on;
end
xlabel('$x_1$','interpreter','latex')
ylabel('$x_2$','interpreter','latex');
grid

%--------------------------------------------------------------

%%r21 = [99.32 99.05 98.85 38.41 38.37 38.08 22.24 21.96 21.99];
r22 = [99.25 98.91 98.56 38.37 38.39 37.77 22.14 21.92 21.88];

plot(alpha,r21(1:3),'bo-','LineWidth',1)
hold on
plot(alpha,r21(4:6),'bs--','LineWidth',1)
hold on
plot(alpha,r21(7:9),'b^-.','LineWidth',1)
hold on

plot(alpha,r22(1:3),'o-','LineWidth',1)
hold on
plot(alpha,r22(4:6),'s--','LineWidth',1)
hold on
plot(alpha,r22(7:9),'^-.','LineWidth',1)
hold on
