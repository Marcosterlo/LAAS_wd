function [x,u] = NN_trigger_w_closedloop_2(Nstep,sysP,x0,W,b, alpha,beta)

AG = sysP.AG;
BG = sysP.BG;

nlayer = numel(W)-1;
n = zeros(1,nlayer);
for i=1:nlayer
    n(i) = size(W{i},1);
end
nphi = sum(n);

Nx = numel(x0);

x = zeros(Nx,Nstep);
x(:,1) = x0;

w = cell(nlayer,1);
for i = 1:nlayer
    w{i,1} = zeros(n(i),1);
end    

Nu = size(W{end},1);
u = zeros(Nu,Nstep);

r = rand(1);
    
%p = r*diag(beta) + (1-r)*diag(alpha);

% Simulate System
for k = 1:Nstep      
    

    w{1,k} = max(zeros(n(1),1), (W{1}*x(:,k) + b{1}));  %p(1:n(1)).*

    for i = 2:nlayer       
        w{i,k} = max(zeros(n(i),1),(W{i}*w{i-1,k} + b{i})); %p(n(1)+1:end).*
    end

    u(:,k) = W{end}*w{end,k}+b{end};
    
    x(:,k+1) = AG*x(:,k)+BG*u(:,k);
    
end
end