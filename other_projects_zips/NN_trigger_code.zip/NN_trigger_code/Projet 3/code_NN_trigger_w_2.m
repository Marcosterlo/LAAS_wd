function [sol,solPb] = code_NN_trigger_w_2(sysP,sysC,alpha,beta)

pbLMI = [];
AG = sysP.AG;
BG = sysP.BG;

nG = size(AG,1);
nlayer = numel(sysC.W)-1;

N = [];
n = zeros(1,nlayer);
W = cell(1,nlayer);
for i=1:nlayer+1
    W{i} = sysC.W{i};
    n(i) = size(W{i},1);
    N = blkdiag(N,W{i});
end
nphi = sum(n(1:nlayer));
Nux = N(nphi+1:end,1:nG);
Nuw = N(nphi+1:end,nG+1:end);
Nvx = N(1:nphi,1:nG);
Nvw = N(1:nphi,nG+1:end);
%%
% Definition des variableset du systeme de LMIs a contruire
% a = sdpvar(1,1);   
% pbLMI = pbLMI + (a>=0);
P = sdpvar(nG,nG,'symmetric');   
pbLMI = pbLMI + (P>=1e-08*eye(size(nG)));%
T = sdpvar(nphi,nphi,'diagonal');
pbLMI = pbLMI + (T>=0); 
M1 = sdpvar(nphi,nphi,'diagonal');  
M2 = sdpvar(nphi,nphi,'diagonal'); 
M3 = sdpvar(nphi,nphi,'diagonal'); 
pbLMI = pbLMI + (M1>=0) + (M2>=0) + (M3>=0);
M = [M1 M2;M2 M3];

Rphis = [Nvx Nvw;
        zeros(nphi,nG) eye(nphi)];         

% Mphi = [zeros(nphi) T;
%         T -2*T]; 
    
Mphi_alpha = [zeros(nphi) alpha*T;
        alpha*T -2*T]; 

Mphi_beta = [zeros(nphi) beta*T;
        beta*T -2*T];     

Qphis = Rphis'*(Mphi_alpha+Mphi_beta)*Rphis; 

% I0 = [-eye(nphi) eye(nphi);zeros(nphi) eye(nphi)];
 
I0_alpha = [-alpha eye(nphi);zeros(nphi) eye(nphi)];

I0_beta = [-beta eye(nphi);zeros(nphi) eye(nphi)];

Qphis0 = Rphis'*(I0_alpha'*M*I0_alpha+I0_beta'*M*I0_beta)*Rphis;

Rs = [eye(nG) zeros(nG,nphi);
      Nux Nuw];

lmi11 = AG'*P*AG-P;
lmi12 = AG'*P*BG;
lmi22 = BG'*P*BG;

Qs = [lmi11  lmi12;
      lmi12' lmi22];

Qlyap = Rs'*Qs*Rs;
%     
MSTAB =  Qlyap + Qphis +  Qphis0;

pbLMI = pbLMI + (MSTAB <= -1e-10*eye(size(MSTAB)));%

% lmi211 = 2^2;
% lmi212 = [1,0];
% lmi222 = P;
% MSETOR2 = [lmi211 lmi212;
%     lmi212' lmi222];
% pbLMI = pbLMI + (MSETOR2>= 0);


% critere d'optimisation
critOPTIM = [];%trace(Qw(1:n1,1:n1));%(n1+1:n1+n2,n1+1:n1+n2)
% les options d'optimisation);%trace(Qw);%%%%
% les options d'optimisation
% --------------------------
options_sdp = sdpsettings('verbose',0,'warning',0,'solver','sdpt3');
options_sdp.sdpt3.maxit    = 300;
options_sdp.lmilab.maxiter = 500;    % default = 100
options_sdp.lmilab.reltol = 0.001;    % default = 0.01?? in lmilab 1e-03
options_sdp.lmilab.feasradius = 1e9; % R<0 signifie "no bound", default = 1e9

% resolution du probleme
solPb = solvesdp(pbLMI,critOPTIM,options_sdp);
%solPb = optimize(pbLMI,critOPTIM,options_sdp);

feasible = min(checkset(pbLMI));
if (feasible >= 0) % && solPb.problem == 0)
    sol.P = double(P);
    sol.T = double(T);
    sol.Q = double([M1;M2;M3]);
else
    sol.P = [];
    sol.T = [];
    sol.Q = [];
end

end