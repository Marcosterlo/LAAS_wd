function [sol,solPb] = code_NN_trigger_w_3(sysP,sysC,alpha,beta,t1,t2,epsilon)

pbLMI = [];
AG = sysP.AG;
BG = sysP.BG;

nG = size(AG,1);
nu = size(BG,2);
nlayer = numel(sysC.W)-1;

N = [];
n = zeros(1,nlayer);
W = cell(1,nlayer);
for i=1:nlayer+1
    W{i} = sysC.W{i};
    n(i) = size(W{i},1);
    N = blkdiag(N,W{i});
end
nphi = sum(n(1:nlayer));
Nux = N(nphi+1:end,1:nG);
Nuw = N(nphi+1:end,nG+1:end);
Nvx = N(1:nphi,1:nG);
Nvw = N(1:nphi,nG+1:end);
%%
% Definition des variableset du systeme de LMIs a contruire
% epsilon = sdpvar(1,1);   
% pbLMI = pbLMI + (epsilon>=1);% + (epsilon<=1);
P = sdpvar(nG,nG,'symmetric');   
pbLMI = pbLMI + (P>=0);
Q = sdpvar(nG,nG,'symmetric');   
pbLMI = pbLMI + (Q>=0);
T = sdpvar(nphi,nphi,'diagonal');
pbLMI = pbLMI + (T>=0);
M1 = sdpvar(nphi,nphi,'diagonal');  
M2 = sdpvar(nphi,nphi,'diagonal'); 
M3 = sdpvar(nphi,1,'full'); 
M4 = sdpvar(nphi,nphi,'diagonal');  
M5 = sdpvar(nphi,1,'full'); 
M6 = sdpvar(1,1,'full'); 
pbLMI = pbLMI + (M1>=0) + (M2>=0) + (M3>=zeros(nphi,1)) + (M5>=zeros(nphi,1)) + (M6>=0) + (M4>=0) ;
M = [M1 M2 M3;M2' M4 M5; M3' M5' M6];

lmi11 = (-1-t1+t2)*P;%-1e-09*eye(nG);%(-1-t1)*P+t2*Q;%
lmi12 = Nvx'*T-Nvx'*(M1+M2);
lmi13 = -Nvx'*M3;
lmi14 = (AG+BG*Nux)'*P;
lmi15 = Nvx'*M1;
lmi22 = T*Nvw+Nvw'*T-2*T-(M1+M2')*Nvw-Nvw'*(M1+M2)+M1+2*M2+M4;
lmi23 = -Nvw'*M3+M3+M5;
lmi24 = (BG*Nuw)'*P;
lmi25 = Nvw'*M1;
lmi33 = t1*epsilon-t2+M6;%
lmi34 = zeros(1,nG);
lmi35 = zeros(1,nphi);
lmi44 = -P;
lmi45 = zeros(nG,nphi);
lmi55 = -M1;

MSTAB = [lmi11  lmi12  lmi13  lmi14  lmi15;
         lmi12' lmi22  lmi23  lmi24  lmi25;
         lmi13' lmi23' lmi33  lmi34  lmi35;
         lmi14' lmi24' lmi34' lmi44  lmi45;
         lmi15' lmi25' lmi35' lmi45' lmi55];
     
% MSTAB = [lmi11  lmi14 ;
%          lmi14'  lmi44];      
      
pbLMI = pbLMI + (MSTAB <= 0);% + (Q-P>=0);% 
% critere d'optimisation
critOPTIM = [];%trace(Qw(1:n1,1:n1));%(n1+1:n1+n2,n1+1:n1+n2)
% les options d'optimisation);%trace(Qw);%%%%
% les options d'optimisation
% --------------------------
options_sdp = sdpsettings('verbose',0,'warning',0,'solver','sdpt3');
options_sdp.sdpt3.maxit    = 200;
options_sdp.lmilab.maxiter = 500;    % default = 100
options_sdp.lmilab.reltol = 0.001;    % default = 0.01?? in lmilab 1e-03
options_sdp.lmilab.feasradius = 1e9; % R<0 signifie "no bound", default = 1e9

% resolution du probleme
solPb = solvesdp(pbLMI,critOPTIM,options_sdp);
%solPb = optimize(pbLMI,critOPTIM,options_sdp);

feasible = min(checkset(pbLMI))
if (feasible >= 0) % && solPb.problem == 0)
    sol.P = double(P);
    sol.T = double(T);
    sol.M = double(M);
    sol.epsilon = double(epsilon);
else
    sol.P = [];
    sol.T = [];
    sol.M = [];
    sol.epsilon = [];
end

end

% Rphis = [Nvx Nvw;
%         zeros(nphi,nG) eye(nphi)];         
% % 
% Mphi = [zeros(nphi) T;
%         T -2*T]; 
%     
% % Mphi_alpha = [zeros(nphi) alpha*T;
% %         alpha*T -2*T]; 
% % 
% % Mphi_beta = [zeros(nphi) beta*T;
% %         beta*T -2*T];     
% 
% Qphis = Rphis'*Mphi*Rphis;%Rphis'*(Mphi_alpha+Mphi_beta)*Rphis; 
% 
% I0 = [-eye(nphi) eye(nphi);zeros(nphi) eye(nphi)];
 
% % I0_alpha = [-alpha eye(nphi);zeros(nphi) eye(nphi)];
% % 
% % I0_beta = [-beta eye(nphi);zeros(nphi) eye(nphi)];
% 
% Qphis0 = Rphis'*(I0'*M*I0)*Rphis;%Rphis'*(I0_alpha'*M*I0_alpha+I0_beta'*M*I0_beta)*Rphis;
% 
% Rs = [eye(nG) zeros(nG,nphi);
%       Nux Nuw];
% % 
% lmi11 = AG'*P*AG+(-1+t1)*P;
% lmi12 = AG'*P*BG;
% lmi22 = BG'*P*BG;
% 
% Qs = [lmi11  lmi12;
%       lmi12' lmi22];
% 
% Qlyap = Rs'*Qs*Rs;
% 
% MSTAB = Qlyap + Qphis + Qphis0;


% lmi11 = (AG+BG*Nux)'*P*(AG+BG*Nux)+(-1+t1)*P + Nvx'*M1*Nvx;%-t2
% lmi12 = (AG+BG*Nux)'*P*BG*Nuw+Nvx'*T+Nvx'*M1*Nvw-Nvx'*(M1+M2);
% lmi22 = (BG*Nuw)'*P*BG*Nuw+T*Nvw+Nvw'*T-2*T+Nvw'*M1*Nvw-(M1+M2)*Nvw-Nvw'*(M1+M2)+M1+2*M2+M3;
% 
% MSTAB = [lmi11  lmi12 ;
%          lmi12' lmi22];   

% lmi11 = (-1-t1)*P+t2*Q;%(-1+t1-t2)*P;%
% lmi12 = Nvx'*T-Nvx'*(M1+M2);
% lmi13 = (AG+BG*Nux)'*P;
% lmi14 = Nvx'*M1;
% lmi22 = T*Nvw+Nvw'*T-2*T-(M1+M2)*Nvw-Nvw'*(M1+M2)+M1+2*M2+M3;
% lmi23 = (BG*Nuw)'*P;
% lmi24 = Nvw'*M1;
% lmi33 = -P;
% lmi34 = zeros(nG,nphi);
% lmi44 = -M1;