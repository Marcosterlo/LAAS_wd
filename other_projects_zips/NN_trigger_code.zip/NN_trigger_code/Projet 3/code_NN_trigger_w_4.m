function [sol,solPb] = code_NN_trigger_w_4(sysP,sysC,alpha,beta,t1,t2,epsilon)


pbLMI = [];
AG = sysP.AG;
BG = sysP.BG;

nG = size(AG,1);
nu = size(BG,2);
nlayer = numel(sysC.W)-1;

N = [];
n = zeros(1,nlayer);
W = cell(1,nlayer);
for i=1:nlayer+1
    W{i} = sysC.W{i};
    n(i) = size(W{i},1);
    N = blkdiag(N,W{i});
end
nphi = sum(n(1:nlayer));
Nux = N(nphi+1:end,1:nG);
Nuw = N(nphi+1:end,nG+1:end);
Nvx = N(1:nphi,1:nG);
Nvw = N(1:nphi,nG+1:end);

alpha = 0.60*eye(nphi);
beta = 1*eye(nphi);
% beta{2} = 1.10*eye(nphi);
%%
% Definition des variableset du systeme de LMIs a contruire
% epsilon = sdpvar(1,1);
% pbLMI = pbLMI + (epsilon>=1);% + (epsilon<=1);
P = sdpvar(nG,nG,'symmetric');
pbLMI = pbLMI + (P>=0);
T = sdpvar(nphi,nphi,'diagonal');
%pbLMI = pbLMI + (T>=0);
M1 = sdpvar(nphi,nphi,'diagonal');
M2 = sdpvar(nphi,nphi,'diagonal');
M3 = sdpvar(nphi,1,'full');
M4 = sdpvar(nphi,nphi,'diagonal');
M5 = sdpvar(nphi,1,'full');
M6 = sdpvar(1,1,'full');
pbLMI = pbLMI  + (M1>=0) + (M2>=0) + (M4>=0) + (M6>=0) + (M3>=zeros(nphi,1)) + (M5>=zeros(nphi,1));
M = [M1 M2 M3;M2' M4 M5; M3' M5' M6];

Rphi = [Nvx Nvw zeros(nphi,1);
    zeros(nphi,nG) eye(nphi) zeros(nphi,1)];

Mphi = [-2*alpha*beta*T  (alpha+beta)*T ;
    (alpha+beta)*T -2*T];

Qphi = Rphi'*Mphi*Rphi;

% lmi111 = -2*Nvx'*alpha*beta*T*Nvx;
% lmi112 = -2*Nvx'*alpha*beta*T*Nvw+Nvx'*(alpha+beta)*T;
% lmi113 = zeros(nG,1);
% lmi122 = -2*Nvw'*alpha*T*beta*Nvw+T*(alpha+beta)*Nvw+Nvw'*(alpha+beta)*T-2*T;
% lmi123 = zeros(nphi,1);
% lmi133 =  0;
% 
% Qphi =  [lmi111  lmi112  lmi113;
%          lmi112' lmi122  lmi123;
%          lmi113' lmi123' lmi133];
     
Rphis = [Nvx Nvw zeros(nphi,1);
    zeros(nphi,nG) eye(nphi) zeros(nphi,1);
    zeros(1,nG) zeros(1,nphi) 1];

I0 = [-beta eye(nphi) zeros(nphi,1);-alpha eye(nphi) zeros(nphi,1);zeros(1,nphi) zeros(1,nphi) 1];

Qphis = Rphis'*I0'*M*I0*Rphis;

% lmi211 = 2*Nvx'*(beta*M1*beta+alpha*M2'*beta+alpha*M4*alpha)*Nvx;
% lmi212 = 2*Nvx'*(beta*M1*beta+alpha*M2'*beta+alpha*M4*alpha)*Nvw-Nvx'*(beta*(M1+M2)+alpha*(M2'+M4));
% lmi213 = -Nvx'*(beta*M3+alpha*M5);
% lmi222 = 2*Nvw'*(beta*M1*beta+alpha*M2'*beta+alpha*M4*alpha)*Nvw-((M1+M2')*beta+(M2+M4)*alpha)*Nvw-Nvw'*(beta*(M1+M2)+alpha*(M2'+M4))+M1+2*M2+M4;
% lmi223 = -Nvw'*(beta*M3+alpha*M5)+M3+M5;
% lmi233 = M6;

% Qphis = [lmi211  lmi212  lmi213;
%          lmi212' lmi222  lmi223;
%          lmi213' lmi223' lmi233];

lmi311 = (AG+BG*Nux)'*P*(AG+BG*Nux)+(-1-t1+t2)*P;%-1e-10*eye(nG);
lmi312 = (AG+BG*Nux)'*P*BG*Nuw;
lmi313 = zeros(nG,1);
lmi322 = (BG*Nuw)'*P*BG*Nuw;
lmi323 = zeros(nphi,1);
lmi333 = t1*epsilon-t2;


Qlyap = [lmi311  lmi312  lmi313;
         lmi312' lmi322  lmi323;
         lmi313' lmi323' lmi333];

MSTAB = Qlyap + Qphi + Qphis;

pbLMI = pbLMI + (MSTAB <= 0) ;

vb = 0.5;
lmi122 = P;
for i = 1:n(1)
    lmi111 = vb^2;
    lmi112 = W{1}(i,:);
    MSETOR = [lmi111 lmi112;
    lmi112' lmi122];
    pbLMI = pbLMI + (MSETOR>=0);
end

x1b = 2.5;
lmi211 = x1b^2;
lmi212 = [1,0];
lmi222 = P;
MSETOR2 = [lmi211 lmi212;
    lmi212' lmi222];
pbLMI = pbLMI + (MSETOR2>=0);

% critere d'optimisation
critOPTIM = trace(P);%trace(Qw(1:n1,1:n1));%(n1+1:n1+n2,n1+1:n1+n2)
% les options d'optimisation);%trace(Qw);%%%%
% les options d'optimisation
% --------------------------
options_sdp = sdpsettings('verbose',0,'warning',0,'solver','sdpt3');
options_sdp.sdpt3.maxit    = 200;
options_sdp.lmilab.maxiter = 500;    % default = 100
options_sdp.lmilab.reltol = 0.001;    % default = 0.01?? in lmilab 1e-03
options_sdp.lmilab.feasradius = 1e9; % R<0 signifie "no bound", default = 1e9

% resolution du probleme
solPb = solvesdp(pbLMI,critOPTIM,options_sdp);
%solPb = optimize(pbLMI,critOPTIM,options_sdp);

feasible = min(checkset(pbLMI))
if (feasible >= 0) % && solPb.problem == 0)
    sol.P = double(P);
    sol.T = double(T);
    sol.M = double(M);
    sol.epsilon = double(epsilon);
else
    sol.P = [];
    sol.T = [];
    sol.M = [];
    sol.epsilon = [];
end

end
% lmi111 = -2*Nvx'*alpha*beta*T*Nvx;
% lmi112 = -2*Nvx'*alpha*beta*T*Nvw+Nvx'*(alpha+beta)*T;
% lmi113 = zeros(nG,1);
% lmi115 = zeros(nG,nphi);
% lmi116 = zeros(nG,nphi);
% lmi122 = -2*Nvw'*alpha*beta*T*Nvw+T*(alpha+beta)*Nvw+Nvw'*(alpha+beta)*T-2*T;
% lmi123 = zeros(nphi,1);
% lmi125 = zeros(nphi);
% lmi126 = zeros(nphi);
% lmi133 =  0;
% lmi135 = zeros(1,nphi);
% lmi136 = zeros(1,nphi);
% lmi155 = zeros(nphi);
% lmi156 = zeros(nphi);
% lmi166 = zeros(nphi);
% 
% Qphi =  [lmi111  lmi112  lmi113  lmi115 lmi116;
%          lmi112' lmi122  lmi123  lmi125 lmi126;
%          lmi113' lmi123' lmi133  lmi135 lmi136;
%          lmi115' lmi125' lmi135' lmi155 lmi156;
%          lmi116' lmi126' lmi136' lmi156 lmi166];

% lmi211 = 2*Nvx'*alpha*M2'*beta*Nvx;
% lmi212 = 2*Nvx'*alpha*M2'*beta*Nvw-Nvx'*(beta*(M1+M2)+alpha*(M2'+M4));
% lmi213 = -Nvx'*(beta*M3+alpha*M5);
% lmi215 = Nvx'*beta*M1;
% lmi216 = Nvx'*alpha*M4;
% lmi222 = 2*Nvw'*alpha*M2'*beta*Nvw-((M1+M2')*beta+(M2+M4)*alpha)*Nvw-Nvw'*(beta*(M1+M2)+alpha*(M2'+M4))+M1+2*M2+M4;
% lmi223 = -Nvw'*(beta*M3+alpha*M5)+M3+M5;
% lmi225 = Nvw'*beta*M1;
% lmi226 = Nvw'*alpha*M4;
% lmi233 = M6;
% lmi235 = zeros(1,nphi);
% lmi236 = zeros(1,nphi);
% lmi255 = -M1;
% lmi256 = zeros(nphi);
% lmi266 = -M4;
% 
% Qphis = [lmi211  lmi212  lmi213  lmi215  lmi216;
%          lmi212' lmi222  lmi223  lmi225  lmi226;
%          lmi213' lmi223' lmi233  lmi235  lmi236;
%          lmi215' lmi225' lmi235' lmi255  lmi256;
%          lmi216' lmi226' lmi236' lmi256' lmi266];

% lmi311 = (AG+BG*Nux)'*P*(AG+BG*Nux)+(-1-t1+t2)*P;%-1e-10*eye(nG);
% lmi312 = (AG+BG*Nux)'*P*BG*Nuw;
% lmi313 = zeros(nG,1);
% lmi315 = zeros(nG,nphi);
% lmi316 = zeros(nG,nphi);
% lmi322 = (BG*Nuw)'*P*BG*Nuw;
% lmi323 = zeros(nphi,1);
% lmi325 = zeros(nphi,nphi);
% lmi326 = zeros(nphi,nphi);
% lmi333 = t1*epsilon-t2;
% lmi335 = zeros(1,nphi);
% lmi336 = zeros(1,nphi);
% lmi355 = zeros(nphi);
% lmi356 = zeros(nphi);
% lmi366 = zeros(nphi);
% 
% Qlyap = [lmi311  lmi312  lmi313  lmi315  lmi316;
%          lmi312' lmi322  lmi323  lmi325  lmi326;
%          lmi313' lmi323' lmi333  lmi335  lmi336;
%          lmi315' lmi325' lmi335' lmi355  lmi356;
%          lmi316' lmi326' lmi336' lmi356' lmi366];

