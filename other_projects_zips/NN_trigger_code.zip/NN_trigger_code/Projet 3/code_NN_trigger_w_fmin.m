function [critOPTIM] = code_NN_trigger_w_fmin(t1)

t2 = 1.8e-02;
epsilon = 1.1;

pbLMI = [];
g = 10;
m = 0.15;
l = 0.5;
mu = 0.05;
dt = 0.02;

AG = [1,      dt;...
    g/l*dt, 1-mu/(m*l^2)*dt];

BG = [0;...
    dt/(m*l^2)];

nG = size(AG,1);
nu = size(BG,2);
%% load weights and biases of the NN controller
% %fname = '../vehicle_training/Wb_s32_tanh/';
fname = 'Wb_s32_relu/';
load([fname 'W1.csv'])
load([fname 'W2.csv'])
load([fname 'W3.csv'])

W{1} = W1;
W{2} = W2;
W{3} = W3;

N = [];
nlayer = numel(W)-1;
b = cell(1,nlayer);
n = zeros(1,nlayer);
for i=1:nlayer+1
    n(i) = size(W{i},1);
    b{i} = zeros(n(i),1);
    N = blkdiag(N,W{i});
end
nphi = sum(n(1:nlayer));
Nux = N(nphi+1:end,1:nG);
Nuw = N(nphi+1:end,nG+1:end);
Nvx = N(1:nphi,1:nG);
Nvw = N(1:nphi,nG+1:end);
%%
% Definition des variableset du systeme de LMIs a contruire
epsilon = sdpvar(1,1);   
pbLMI = pbLMI + (epsilon>=1) ;%+ (epsilon<=1);
P = sdpvar(nG,nG,'symmetric');   
pbLMI = pbLMI + (P>=0);
Q = sdpvar(nG,nG,'symmetric');   
pbLMI = pbLMI + (Q>=0);
T = sdpvar(nphi,nphi,'diagonal');
pbLMI = pbLMI + (T>=0);
M1 = sdpvar(nphi,nphi,'diagonal');  
M2 = sdpvar(nphi,nphi,'diagonal'); 
M3 = sdpvar(nphi,1,'full'); 
M4 = sdpvar(nphi,nphi,'diagonal');  
M5 = sdpvar(nphi,1,'full'); 
M6 = sdpvar(1,1,'full'); 
pbLMI = pbLMI + (M1>=0) + (M2>=0) + (M3>=zeros(nphi,1)) + (M5>=zeros(nphi,1)) + (M6>=0) + (M4>=0) ;
M = [M1 M2 M3;M2' M4 M5; M3' M5' M6];

lmi11 = (-1-t1+t2)*P-1e-09*eye(nG);%(-1-t1)*P+t2*Q;%
lmi12 = Nvx'*T-Nvx'*(M1+M2);
lmi13 = -Nvx'*M3;
lmi14 = (AG+BG*Nux)'*P;
lmi15 = Nvx'*M1;
lmi22 = T*Nvw+Nvw'*T-2*T-(M1+M2')*Nvw-Nvw'*(M1+M2)+M1+2*M2+M4;
lmi23 = -Nvw'*M3+M3+M5;
lmi24 = (BG*Nuw)'*P;
lmi25 = Nvw'*M1;
lmi33 = t1*epsilon-t2+M6;%
lmi34 = zeros(1,nG);
lmi35 = zeros(1,nphi);
lmi44 = -P;
lmi45 = zeros(nG,nphi);
lmi55 = -M1;

MSTAB = [lmi11  lmi12  lmi13  lmi14  lmi15;
         lmi12' lmi22  lmi23  lmi24  lmi25;
         lmi13' lmi23' lmi33  lmi34  lmi35;
         lmi14' lmi24' lmi34' lmi44  lmi45;
         lmi15' lmi25' lmi35' lmi45' lmi55];
     
% MSTAB = [lmi11  lmi14 ;
%          lmi14'  lmi44];      
      
pbLMI = pbLMI + (MSTAB <= 0);% + (Q-P>=0);% 
% critere d'optimisation
critOPTIM = -epsilon;%trace(Qw(1:n1,1:n1));%(n1+1:n1+n2,n1+1:n1+n2)
% les options d'optimisation);%trace(Qw);%%%%
% les options d'optimisation
% --------------------------
options_sdp = sdpsettings('verbose',0,'warning',0,'solver','sdpt3');
options_sdp.sdpt3.maxit    = 200;
options_sdp.lmilab.maxiter = 500;    % default = 100
options_sdp.lmilab.reltol = 0.001;    % default = 0.01?? in lmilab 1e-03
options_sdp.lmilab.feasradius = 1e9; % R<0 signifie "no bound", default = 1e9

% resolution du probleme
solPb = solvesdp(pbLMI,critOPTIM,options_sdp);
%solPb = optimize(pbLMI,critOPTIM,options_sdp);

 feasible = min(checkset(pbLMI));
if (feasible >= 0) % && solPb.problem == 0)
    sol.P = double(P);
    sol.T = double(T);
    sol.M = double(M);
    sol.epsilon = double(epsilon);
    critOPTIM = double(critOPTIM);
else
    sol.P = [];
    sol.T = [];
    sol.M = [];
    sol.epsilon = [];
    critOPTIM = -1;
end

end