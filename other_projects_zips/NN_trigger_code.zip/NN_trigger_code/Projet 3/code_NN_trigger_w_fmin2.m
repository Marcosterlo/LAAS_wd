function [critOPTIM] = code_NN_trigger_w_fmin2(epsilon)

t1 = 1.6e-04;
t2 = 1.6e-03;

pbLMI = [];
g = 10;
m = 0.15;
l = 0.5;
mu = 0.05;
dt = 0.02;

AG = [1,      dt;...
    g/l*dt, 1-mu/(m*l^2)*dt];

BG = [0;...
    dt/(m*l^2)];

nG = size(AG,1);
nu = size(BG,2);
%% load weights and biases of the NN controller
% %fname = '../vehicle_training/Wb_s32_tanh/';
fname = 'Wb_s32_relu/';
load([fname 'W1.csv'])
load([fname 'W2.csv'])
load([fname 'W3.csv'])

W{1} = W1;
W{2} = W2;
W{3} = W3;

N = [];
nlayer = numel(W)-1;
b = cell(1,nlayer);
n = zeros(1,nlayer);
for i=1:nlayer+1
    n(i) = size(W{i},1);
    b{i} = zeros(n(i),1);
    N = blkdiag(N,W{i});
end
nphi = sum(n(1:nlayer));
Nux = N(nphi+1:end,1:nG);
Nuw = N(nphi+1:end,nG+1:end);
Nvx = N(1:nphi,1:nG);
Nvw = N(1:nphi,nG+1:end);

alpha = 0.58*eye(nphi);
beta = 1*eye(nphi);
%%
% Definition des variableset du systeme de LMIs a contruire
lambda = sdpvar(1,1);
pbLMI = pbLMI + (lambda>=0);% + (epsilon<=1);
P = sdpvar(nG,nG,'symmetric');
pbLMI = pbLMI + (P>=0);% + (P<=1e3*lambda*eye(nG));
T = sdpvar(nphi,nphi,'diagonal');
pbLMI = pbLMI + (T>=0);
M3 = sdpvar(nphi,1,'full');
M5 = sdpvar(nphi,1,'full');
pbLMI = pbLMI + (M3>=zeros(nphi,1)) + (M5>=zeros(nphi,1));
M = [M3;M5];

Rphi = [Nvx Nvw zeros(nphi,1);
    zeros(nphi,nG) eye(nphi) zeros(nphi,1);
    zeros(1,nG) zeros(1,nphi) 1];

Mphi = [-2*alpha*beta*T  (alpha+beta)*T -beta*M3-alpha*M5;
    (alpha+beta)*T -2*T M3+M5;
    -M3'*beta-M5'*alpha M3'+M5' 0];

Qphi = Rphi'*Mphi*Rphi;

% lmi111 = -2*Nvx'*alpha*beta*T*Nvx;
% lmi112 = -2*Nvx'*alpha*beta*T*Nvw+Nvx'*(alpha+beta)*T;
% lmi113 = -Nvx'*(beta*M3+alpha*M5);
% lmi114 = zeros(nG);
% lmi122 = -2*Nvw'*alpha*beta*T*Nvw+T*(alpha+beta)*Nvw+Nvw'*(alpha+beta)*T-2*T;
% lmi123 = -Nvw'*(beta*M3+alpha*M5)+M3+M5;
% lmi124 = zeros(nphi,nG);
% lmi133 =  0;
% lmi134 = zeros(1,nG);
% lmi144 = zeros(nG);
% 
% Qphi =  [lmi111  lmi112  lmi113  lmi114;
%          lmi112' lmi122  lmi123  lmi124;
%          lmi113' lmi123' lmi133  lmi134;
%          lmi114' lmi124' lmi134' lmi144];
     
lmi311 = (AG+BG*Nux)'*P*(AG+BG*Nux)+(-1-t1+t2)*P;%-1e-12*eye(nG);
lmi312 = (AG+BG*Nux)'*P*BG*Nuw;
lmi313 = zeros(nG,1);
lmi322 = Nuw'*BG'*P*BG*Nuw;
lmi323 = zeros(nphi,1);
lmi333 = t1*epsilon-t2;

Qlyap = [lmi311  lmi312  lmi313;
         lmi312' lmi322  lmi323;
         lmi313' lmi323' lmi333];
 
% Qlyap = [lmi311  lmi312;
%          lmi312' lmi322];
          
MSTAB =  Qlyap + Qphi; 

pbLMI = pbLMI + (MSTAB <= 0) ;

vb = 0.1;
lmi122 = P;
for i = 1:n(1)
    lmi111 = vb^2;
    lmi112 = W{1}(i,:);
    MSETOR = [lmi111 lmi112;
    lmi112' lmi122];
    pbLMI = pbLMI + (MSETOR>=0);
end

x1b = 0.73;
lmi211 = x1b^2;
lmi212 = [1,0];
lmi222 = P;
MSETOR2 = [lmi211 lmi212;
    lmi212' lmi222];
pbLMI = pbLMI + (MSETOR2>=0);
    
% critere d'optimisation
critOPTIM = trace(P);%trace(Qw(1:n1,1:n1));%(n1+1:n1+n2,n1+1:n1+n2)
% les options d'optimisation);%trace(Qw);%%%%
% les options d'optimisation
% --------------------------
options_sdp = sdpsettings('verbose',0,'warning',0,'solver','sdpt3');
options_sdp.sdpt3.maxit    = 200;
options_sdp.lmilab.maxiter = 500;    % default = 100
options_sdp.lmilab.reltol = 0.001;    % default = 0.01?? in lmilab 1e-03
options_sdp.lmilab.feasradius = 1e9; % R<0 signifie "no bound", default = 1e9

% resolution du probleme
solPb = solvesdp(pbLMI,critOPTIM,options_sdp);
%solPb = optimize(pbLMI,critOPTIM,options_sdp);

feasible = min(checkset(pbLMI))
if (feasible >= 0) % && solPb.problem == 0)
    sol.P = double(P);
    sol.T = double(T);
    sol.M = double(M);
    sol.epsilon = double(epsilon);
    critOPTIM = double(critOPTIM);
else
    sol.P = [];
    sol.T = [];
    sol.M = [];
    sol.epsilon = [];
    critOPTIM = -1;
end

end
